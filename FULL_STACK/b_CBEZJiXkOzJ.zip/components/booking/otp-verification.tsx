'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import axios from 'axios'
import { Loader } from 'lucide-react'

interface OTPVerificationProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  email: string
  phone: string
  method?: 'email' | 'phone'
}

export function OTPVerification({
  isOpen,
  onClose,
  onSuccess,
  email,
  phone,
  method = 'email',
}: OTPVerificationProps) {
  const [otp, setOtp] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isResending, setIsResending] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<'email' | 'phone'>(method)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes
  const [otpSent, setOtpSent] = useState(false)

  // Timer for OTP expiry
  useEffect(() => {
    if (!otpSent || timeLeft <= 0) return

    const timer = setTimeout(() => {
      setTimeLeft(t => t - 1)
    }, 1000)

    return () => clearTimeout(timer)
  }, [timeLeft, otpSent])

  // Send OTP when modal opens
  useEffect(() => {
    if (isOpen && !otpSent) {
      sendOTP()
    }
  }, [isOpen])

  const sendOTP = async () => {
    try {
      setIsResending(true)
      const token = localStorage.getItem('token')

      const response = await axios.post(
        '/api/otp/send',
        { method: selectedMethod, purpose: 'booking' },
        { headers: { Authorization: `Bearer ${token}` } }
      )

      if (response.data.success) {
        setOtpSent(true)
        setTimeLeft(300)
        toast.success(`OTP sent to your ${selectedMethod}`)
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to send OTP')
    } finally {
      setIsResending(false)
    }
  }

  const verifyOTP = async () => {
    if (otp.length < 6) {
      toast.error('Please enter a valid 6-digit OTP')
      return
    }

    try {
      setIsLoading(true)
      const token = localStorage.getItem('token')

      const response = await axios.post(
        '/api/otp/verify',
        { code: otp, method: selectedMethod, purpose: 'booking' },
        { headers: { Authorization: `Bearer ${token}` } }
      )

      if (response.data.success) {
        toast.success('OTP verified successfully!')
        onSuccess()
        setOtp('')
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Invalid OTP')
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Verify with OTP</DialogTitle>
          <DialogDescription>
            We&apos;ve sent a One-Time Password to your {selectedMethod}. Enter it below to confirm your booking.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Method Selection */}
          <div className="flex gap-2">
            <Button
              variant={selectedMethod === 'email' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedMethod('email')}
              disabled={isResending}
            >
              Email
            </Button>
            <Button
              variant={selectedMethod === 'phone' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedMethod('phone')}
              disabled={isResending}
            >
              Phone
            </Button>
          </div>

          {/* Destination Display */}
          <div className="bg-muted p-3 rounded text-sm">
            <p className="text-muted-foreground">
              OTP sent to:
              {selectedMethod === 'email' ? (
                <span className="font-mono ml-2">{email}</span>
              ) : (
                <span className="font-mono ml-2">+91 {phone.slice(-4)}</span>
              )}
            </p>
          </div>

          {/* OTP Input */}
          <div>
            <Input
              placeholder="Enter 6-digit OTP"
              value={otp}
              onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
              maxLength={6}
              disabled={isLoading || !otpSent}
              className="text-center text-2xl letter-spacing tracking-widest font-mono"
            />
          </div>

          {/* Timer */}
          <div className="text-center text-sm">
            {timeLeft > 0 ? (
              <p className="text-muted-foreground">
                OTP expires in: <span className="font-mono font-semibold">{formatTime(timeLeft)}</span>
              </p>
            ) : (
              <p className="text-destructive">OTP has expired. Request a new one.</p>
            )}
          </div>

          {/* Resend Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={sendOTP}
            disabled={isResending || timeLeft > 240} // Show after 1 minute
            className="w-full"
          >
            {isResending ? (
              <>
                <Loader className="w-4 h-4 animate-spin mr-2" />
                Sending...
              </>
            ) : (
              'Resend OTP'
            )}
          </Button>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              Cancel
            </Button>
            <Button onClick={verifyOTP} disabled={isLoading || otp.length < 6} className="flex-1">
              {isLoading ? (
                <>
                  <Loader className="w-4 h-4 animate-spin mr-2" />
                  Verifying...
                </>
              ) : (
                'Verify OTP'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
