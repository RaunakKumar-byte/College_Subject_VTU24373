'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { bookingSchema, type BookingInput } from '@/lib/validation'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { PAYMENT_METHODS } from '@/lib/constants'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'

interface BookingFormProps {
  eventId: string
  selectedSeats: string[]
  ticketPrice: number
  onSubmit: (data: BookingInput) => void
  isLoading?: boolean
  onOTPMethodChange?: (method: 'email' | 'phone') => void
}

export function BookingForm({
  eventId,
  selectedSeats,
  ticketPrice,
  onSubmit,
  isLoading = false,
  onOTPMethodChange,
}: BookingFormProps) {
  const form = useForm<BookingInput>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      eventId,
      attendeeName: '',
      attendeeEmail: '',
      attendeePhone: '',
      seatNumbers: selectedSeats,
      paymentMethod: 'CreditCard',
      termsAccepted: false,
    },
  })

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Attendee Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Attendee Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="attendeeName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="attendeeEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="john@example.com" {...field} />
                  </FormControl>
                  <FormDescription>We&apos;ll send your ticket confirmation here</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="attendeePhone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input placeholder="9876543210" {...field} />
                  </FormControl>
                  <FormDescription>10-digit Indian mobile number</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        {/* OTP Verification Method */}
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <span className="text-primary">🔐</span>
              Verification Method
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup defaultValue="email" onValueChange={(value: any) => onOTPMethodChange?.(value)}>
              <div className="flex items-center space-x-2 mb-3 p-3 rounded border cursor-pointer hover:bg-muted/30">
                <RadioGroupItem value="email" id="email-otp" />
                <Label htmlFor="email-otp" className="flex-1 cursor-pointer">
                  <div className="font-semibold text-sm">Email OTP</div>
                  <div className="text-xs text-muted-foreground">
                    OTP will be sent to {form.watch('attendeeEmail') || 'your email'}
                  </div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 rounded border cursor-pointer hover:bg-muted/30">
                <RadioGroupItem value="phone" id="phone-otp" />
                <Label htmlFor="phone-otp" className="flex-1 cursor-pointer">
                  <div className="font-semibold text-sm">SMS OTP</div>
                  <div className="text-xs text-muted-foreground">
                    OTP will be sent to {form.watch('attendeePhone') ? `+91 ${form.watch('attendeePhone').slice(-4)}` : 'your phone'}
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Payment Method</CardTitle>
          </CardHeader>
          <CardContent>
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        {PAYMENT_METHODS.map((method) => (
                          <SelectItem key={method.value} value={method.value}>
                            {method.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        {/* Terms */}
        <Card>
          <CardContent className="pt-6">
            <FormField
              control={form.control}
              name="termsAccepted"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm font-normal cursor-pointer">
                      I agree to the terms and conditions and privacy policy
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Button type="submit" className="w-full" disabled={isLoading || selectedSeats.length === 0}>
          {isLoading ? 'Processing...' : `Pay ₹${(selectedSeats.length * ticketPrice).toLocaleString('en-IN')}`}
        </Button>
      </form>
    </Form>
  )
}
