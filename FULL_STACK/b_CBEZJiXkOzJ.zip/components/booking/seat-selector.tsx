'use client'

import { useSeatSelection } from '@/hooks/useSeatSelection'
import { cn } from '@/lib/utils'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { SEAT_LAYOUT } from '@/lib/constants'

interface SeatSelectorProps {
  eventId: string
  bookedSeats?: string[]
  onSelectionChange?: (selectedSeats: string[]) => void
  maxSelectable?: number
}

export function SeatSelector({
  eventId,
  bookedSeats = [],
  onSelectionChange,
  maxSelectable = 10,
}: SeatSelectorProps) {
  const { selectedSeats, hoveredSeat, setHoveredSeat, getSeatsByRow, isSeatSelectable, toggleSeat } =
    useSeatSelection(eventId, bookedSeats)

  const handleSeatClick = (seatNumber: string) => {
    if (
      selectedSeats.includes(seatNumber) ||
      selectedSeats.length < maxSelectable ||
      selectedSeats.length === maxSelectable
    ) {
      const selected = toggleSeat(seatNumber)
      if (selected) {
        onSelectionChange?.([...selectedSeats])
      }
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Seats</CardTitle>
        <CardDescription>
          {selectedSeats.length === 0
            ? 'Choose your preferred seats'
            : `${selectedSeats.length} seat${selectedSeats.length !== 1 ? 's' : ''} selected`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Legend */}
        <div className="flex flex-wrap gap-4 justify-center">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-muted border border-input" />
            <span className="text-sm text-muted-foreground">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-primary" />
            <span className="text-sm text-muted-foreground">Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-muted cursor-not-allowed" />
            <span className="text-sm text-muted-foreground">Booked</span>
          </div>
        </div>

        {/* Stage Indicator */}
        <div className="text-center">
          <div className="inline-block border-4 border-primary rounded-lg px-8 py-2">
            <span className="font-semibold text-sm">STAGE</span>
          </div>
        </div>

        {/* Seat Grid */}
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full">
            {SEAT_LAYOUT.ROWS.map((row) => (
              <div key={row} className="flex items-center gap-1 justify-center mb-2">
                {/* Row Label */}
                <div className="w-6 text-center text-xs font-semibold text-muted-foreground">{row}</div>

                {/* Seats */}
                <div className="flex gap-1">
                  {getSeatsByRow(row).map((seat) => {
                    const isSelected = selectedSeats.includes(seat.seatNumber)
                    const isBooked = bookedSeats.includes(seat.seatNumber)
                    const isHovered = hoveredSeat === seat.seatNumber
                    const isSelectable = isSeatSelectable(seat.seatNumber)

                    return (
                      <button
                        key={seat.seatNumber}
                        onClick={() => handleSeatClick(seat.seatNumber)}
                        onMouseEnter={() => setHoveredSeat(seat.seatNumber)}
                        onMouseLeave={() => setHoveredSeat(null)}
                        disabled={isBooked || (selectedSeats.length >= maxSelectable && !isSelected)}
                        className={cn(
                          'h-6 w-6 rounded text-xs font-bold flex items-center justify-center transition-all',
                          isBooked && 'bg-muted cursor-not-allowed border border-muted-foreground/30',
                          !isBooked &&
                            isSelected &&
                            'bg-primary text-primary-foreground border border-primary hover:scale-105',
                          !isBooked &&
                            !isSelected &&
                            isSelectable &&
                            'bg-muted border border-input hover:border-primary hover:scale-105 cursor-pointer',
                          isHovered && 'scale-105',
                        )}
                        title={`Seat ${seat.seatNumber}`}
                      >
                        {isSelected && '✓'}
                      </button>
                    )
                  })}
                </div>

                {/* Row Label (Right) */}
                <div className="w-6 text-center text-xs font-semibold text-muted-foreground">{row}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Seats Display */}
        {selectedSeats.length > 0 && (
          <div className="bg-muted rounded-lg p-4">
            <p className="text-sm font-medium text-foreground mb-2">Selected Seats:</p>
            <div className="flex flex-wrap gap-2">
              {selectedSeats.map((seat) => (
                <span key={seat} className="bg-primary text-primary-foreground px-3 py-1 rounded text-sm">
                  {seat}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Info */}
        <p className="text-xs text-muted-foreground text-center">
          You can select up to {maxSelectable} seat{maxSelectable !== 1 ? 's' : ''}
        </p>
      </CardContent>
    </Card>
  )
}
