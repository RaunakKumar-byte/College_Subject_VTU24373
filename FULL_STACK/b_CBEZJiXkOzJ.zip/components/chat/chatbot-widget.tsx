'use client'

import { useState, useRef, useEffect } from 'react'
import { MessageCircle, Send, X, Loader, HelpCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { toast } from 'sonner'
import axios from 'axios'

interface Message {
  id: string
  text: string
  sender: 'user' | 'bot'
  timestamp: Date
}

interface FAQ {
  question: string
  answer: string
}

export function ChatbotWidget({ eventId }: { eventId?: string }) {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm EventHub's AI Assistant. How can I help you today? Ask me about events, bookings, tickets, or anything else!",
      sender: 'bot',
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [showFAQ, setShowFAQ] = useState(false)
  const [faqs, setFaqs] = useState<FAQ[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Load FAQs
  useEffect(() => {
    const loadFAQs = async () => {
      try {
        const response = await axios.get('/api/chat/faq')
        if (response.data.success) {
          setFaqs(response.data.faqs)
        }
      } catch (error) {
        console.error('Failed to load FAQs:', error)
      }
    }

    loadFAQs()
  }, [])

  const sendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    try {
      const response = await axios.post('/api/chat/message', {
        message: inputValue,
        eventContext: eventId,
      })

      if (response.data.success) {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: response.data.message,
          sender: 'bot',
          timestamp: new Date(),
        }
        setMessages(prev => [...prev, botMessage])
      }
    } catch (error) {
      console.error('Chat error:', error)
      toast.error('Failed to get response. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleFAQClick = (answer: string) => {
    const botMessage: Message = {
      id: Date.now().toString(),
      text: answer,
      sender: 'bot',
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, botMessage])
    setShowFAQ(false)
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen ? (
        <Card className="w-96 h-[600px] flex flex-col shadow-lg">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-4 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              <h3 className="font-semibold">EventHub Assistant</h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 hover:bg-primary-foreground/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 bg-background/50 space-y-3">
            {messages.map(message => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <span className="text-xs opacity-70">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-muted-foreground px-4 py-2 rounded-lg">
                  <Loader className="w-4 h-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* FAQ Toggle */}
          {!showFAQ && (
            <div className="px-4 py-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFAQ(true)}
                className="w-full gap-2"
              >
                <HelpCircle className="w-4 h-4" />
                View FAQs
              </Button>
            </div>
          )}

          {/* FAQ Section */}
          {showFAQ && (
            <div className="p-4 border-t max-h-32 overflow-y-auto bg-muted/20">
              <button
                onClick={() => setShowFAQ(false)}
                className="text-sm text-primary mb-2 font-semibold"
              >
                ← Back to Chat
              </button>
              <div className="space-y-2">
                {faqs.slice(0, 3).map((faq, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleFAQClick(faq.answer)}
                    className="text-left text-xs p-2 bg-background rounded hover:bg-primary/10 transition-colors"
                  >
                    <p className="font-semibold text-muted-foreground">{faq.question}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          {!showFAQ && (
            <div className="border-t p-3 flex gap-2 bg-background">
              <Input
                placeholder="Type your message..."
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && sendMessage()}
                disabled={isLoading}
                className="text-sm"
              />
              <Button
                size="icon"
                onClick={sendMessage}
                disabled={isLoading || !inputValue.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          )}
        </Card>
      ) : (
        <Button
          onClick={() => setIsOpen(true)}
          size="lg"
          className="rounded-full shadow-lg h-14 w-14 p-0"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      )}
    </div>
  )
}
