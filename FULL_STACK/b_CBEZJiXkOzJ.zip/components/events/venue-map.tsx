'use client'

import { useEffect, useRef } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MapPin, Navigation } from 'lucide-react'

interface VenueMapProps {
  venue: {
    name: string
    address: string
    city: string
    state: string
    postalCode: string
    latitude?: number
    longitude?: number
  }
}

export function VenueMap({ venue }: VenueMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)

  // Use default coordinates if not provided (you can replace with actual coordinates)
  const latitude = venue.latitude || 28.7041 // Default to Delhi
  const longitude = venue.longitude || 77.1025

  const fullAddress = `${venue.name}, ${venue.address}, ${venue.city}, ${venue.state} ${venue.postalCode}`

  const handleGetDirections = () => {
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
      fullAddress
    )}&destination_place_id=`
    window.open(mapsUrl, '_blank')
  }

  useEffect(() => {
    // Note: This is a fallback using static map API since embedding Google Maps requires API key
    // In production, you would use the Google Maps JavaScript API
    if (mapRef.current) {
      // Create a simple map placeholder
      mapRef.current.innerHTML = `
        <div style="
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          border-radius: 8px;
          color: white;
        ">
          <div style="font-size: 48px; margin-bottom: 16px;">📍</div>
          <div style="text-align: center; font-size: 14px;">
            <p style="margin: 8px 0; font-weight: 600;">${venue.name}</p>
            <p style="margin: 4px 0; font-size: 12px; opacity: 0.9;">${venue.address}</p>
            <p style="margin: 4px 0; font-size: 12px; opacity: 0.9;">${venue.city}, ${venue.state}</p>
          </div>
          <div style="margin-top: 16px; font-size: 11px; opacity: 0.8;">
            Coordinates: ${latitude.toFixed(4)}°N, ${longitude.toFixed(4)}°E
          </div>
        </div>
      `
    }
  }, [venue, latitude, longitude])

  return (
    <Card className="p-4 space-y-4">
      <div>
        <h3 className="font-semibold text-lg flex items-center gap-2 mb-2">
          <MapPin className="w-5 h-5 text-primary" />
          Event Venue
        </h3>

        {/* Map Container */}
        <div
          ref={mapRef}
          className="w-full h-64 bg-muted rounded-lg overflow-hidden"
        />
      </div>

      {/* Venue Details */}
      <div className="space-y-2 text-sm">
        <div>
          <p className="font-semibold text-muted-foreground">Venue Name</p>
          <p className="text-foreground">{venue.name}</p>
        </div>

        <div>
          <p className="font-semibold text-muted-foreground">Address</p>
          <p className="text-foreground">{venue.address}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="font-semibold text-muted-foreground">City</p>
            <p className="text-foreground">{venue.city}</p>
          </div>
          <div>
            <p className="font-semibold text-muted-foreground">State</p>
            <p className="text-foreground">{venue.state}</p>
          </div>
        </div>

        <div>
          <p className="font-semibold text-muted-foreground">Postal Code</p>
          <p className="text-foreground">{venue.postalCode}</p>
        </div>

        {venue.latitude && venue.longitude && (
          <div>
            <p className="font-semibold text-muted-foreground">Coordinates</p>
            <p className="text-foreground font-mono text-xs">
              {venue.latitude.toFixed(6)}°N, {venue.longitude.toFixed(6)}°E
            </p>
          </div>
        )}
      </div>

      {/* Directions Button */}
      <Button onClick={handleGetDirections} className="w-full gap-2" variant="default">
        <Navigation className="w-4 h-4" />
        Get Directions on Google Maps
      </Button>

      {/* Alternative Links */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const mapsUrl = `https://maps.google.com/maps?q=${latitude},${longitude}`
            window.open(mapsUrl, '_blank')
          }}
        >
          View on Maps
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const url = `https://www.google.com/search?q=${encodeURIComponent(fullAddress)}`
            window.open(url, '_blank')
          }}
        >
          Search Location
        </Button>
      </div>
    </Card>
  )
}
