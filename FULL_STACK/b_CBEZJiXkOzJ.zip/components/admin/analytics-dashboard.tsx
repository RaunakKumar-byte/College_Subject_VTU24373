'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useEvents } from '@/hooks/useEvents'
import { useBookings } from '@/hooks/useBookings'
import { formatPrice } from '@/lib/utils'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts'
import { DollarSign, Users, Ticket, TrendingUp } from 'lucide-react'

export function AnalyticsDashboard() {
  const { allEvents } = useEvents()
  const { bookings } = useBookings()

  // Calculate statistics
  const confirmedBookings = bookings.filter((b) => b.status === 'Confirmed')
  const totalRevenue = confirmedBookings.reduce((sum, b) => sum + b.totalPrice, 0)
  const totalBookings = confirmedBookings.length
  const totalSeatsBooked = confirmedBookings.reduce((sum, b) => sum + b.quantity, 0)

  // Event-wise analytics
  const eventStats = allEvents.map((event) => {
    const eventBookings = confirmedBookings.filter((b) => b.eventId === event.id)
    const revenue = eventBookings.reduce((sum, b) => sum + b.totalPrice, 0)
    return {
      name: event.title.substring(0, 15),
      bookings: eventBookings.length,
      revenue: revenue / 1000, // in thousands for better visualization
      occupancy: Math.round(
        ((event.totalSeats - event.availableSeats) / event.totalSeats) * 100
      ),
    }
  })

  // Revenue trend (mock data)
  const revenueTrend = [
    { date: 'Week 1', revenue: 15000 },
    { date: 'Week 2', revenue: 24000 },
    { date: 'Week 3', revenue: 31000 },
    { date: 'Week 4', revenue: 45000 },
  ]

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{formatPrice(totalRevenue)}</div>
            <p className="text-xs text-muted-foreground">From confirmed bookings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
            <Ticket className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{totalBookings}</div>
            <p className="text-xs text-muted-foreground">Confirmed tickets sold</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Seats Booked</CardTitle>
            <Users className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{totalSeatsBooked}</div>
            <p className="text-xs text-muted-foreground">Total seat bookings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Events</CardTitle>
            <TrendingUp className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{allEvents.length}</div>
            <p className="text-xs text-muted-foreground">Total events created</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Booking by Event */}
        <Card>
          <CardHeader>
            <CardTitle>Bookings by Event</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={eventStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="bookings" fill="#3b82f6" name="Bookings" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Revenue Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Occupancy Rates */}
      <Card>
        <CardHeader>
          <CardTitle>Event Occupancy Rates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {eventStats.map((stat) => (
              <div key={stat.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-foreground">{stat.name}</span>
                  <span className="text-sm text-muted-foreground">{stat.occupancy}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${stat.occupancy}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
