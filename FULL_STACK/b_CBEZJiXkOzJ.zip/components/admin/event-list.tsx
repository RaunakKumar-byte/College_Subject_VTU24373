'use client'

import { Event } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { formatDate, formatPrice } from '@/lib/utils'
import { Edit2, Trash2, Users, DollarSign } from 'lucide-react'

interface EventListProps {
  events: Event[]
  onDelete: (eventId: string) => void
  onEdit: (event: Event) => void
  isDeleting?: boolean
}

export function EventList({ events, onDelete, onEdit, isDeleting = false }: EventListProps) {
  if (events.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center text-muted-foreground">
          No events created yet. Start by creating a new event.
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {events.map((event) => {
        const bookedSeats = event.totalSeats - event.availableSeats
        const occupancyRate = Math.round((bookedSeats / event.totalSeats) * 100)
        const revenue = bookedSeats * event.ticketPrice

        return (
          <Card key={event.id}>
            <CardContent className="pt-6">
              <div className="grid gap-6 md:grid-cols-5">
                {/* Event Info */}
                <div className="md:col-span-2">
                  <h3 className="font-semibold text-foreground mb-1">{event.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{event.category}</p>
                  <p className="text-xs text-muted-foreground">{event.location}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(event.startDate)}</p>
                </div>

                {/* Stats */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      <span className="font-semibold">{bookedSeats}</span> / {event.totalSeats} booked
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {occupancyRate}% occupancy
                  </div>
                  <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${occupancyRate}%` }}
                    />
                  </div>
                </div>

                {/* Revenue */}
                <div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span className="font-semibold text-primary">{formatPrice(revenue)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">revenue</p>
                </div>

                {/* Actions */}
                <div className="flex gap-2 justify-end md:justify-start">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onEdit(event)}
                  >
                    <Edit2 className="h-4 w-4 mr-1" />
                    Edit
                  </Button>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="sm" variant="destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogTitle>Delete Event</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete this event? This action cannot be undone.
                      </AlertDialogDescription>
                      <div className="flex gap-3 justify-end">
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(event.id)}
                          className="bg-destructive"
                          disabled={isDeleting}
                        >
                          Delete
                        </AlertDialogAction>
                      </div>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
