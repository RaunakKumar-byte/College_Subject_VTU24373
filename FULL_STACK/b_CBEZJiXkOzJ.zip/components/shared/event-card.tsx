'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Event } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { formatDate, formatPrice, getDaysUntilEvent } from '@/lib/utils'
import { Calendar, MapPin, Users } from 'lucide-react'

interface EventCardProps {
  event: Event
}

export function EventCard({ event }: EventCardProps) {
  const daysUntil = getDaysUntilEvent(event.startDate)
  const occupancyRate = Math.round(((event.totalSeats - event.availableSeats) / event.totalSeats) * 100)

  return (
    <Card className="flex flex-col overflow-hidden transition-all hover:shadow-lg">
      {/* Image */}
      <div className="relative h-48 overflow-hidden bg-muted">
        <Image
          src={event.image}
          alt={event.title}
          fill
          className="object-cover transition-transform hover:scale-105"
        />
        <Badge className="absolute right-3 top-3">{event.category}</Badge>
      </div>

      {/* Content */}
      <CardHeader className="pb-3">
        <h3 className="line-clamp-2 text-lg font-semibold text-foreground">{event.title}</h3>
      </CardHeader>

      <CardContent className="flex flex-grow flex-col justify-between gap-4 pb-4">
        {/* Details */}
        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>{formatDate(event.startDate)}</span>
            {daysUntil >= 0 && <span className="ml-auto text-xs font-medium">{daysUntil} days away</span>}
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span className="line-clamp-1">{event.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>{event.availableSeats} seats available</span>
            <span className="ml-auto text-xs font-medium">{occupancyRate}% booked</span>
          </div>
        </div>

        {/* Price and Button */}
        <div className="flex items-center justify-between gap-3 border-t pt-4">
          <div className="text-xl font-bold text-primary">{formatPrice(event.ticketPrice)}</div>
          <Link href={`/booking/${event.id}`} className="w-full">
            <Button className="w-full" disabled={event.availableSeats === 0}>
              {event.availableSeats > 0 ? 'Book Now' : 'Sold Out'}
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
