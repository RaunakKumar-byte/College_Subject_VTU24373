'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Menu, X, Ticket } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userRole, setUserRole] = useState<'admin' | 'user' | null>(null)

  return (
    <header className="sticky top-0 z-50 border-b bg-background">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <Ticket className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-foreground">EventHub</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden gap-8 md:flex">
          <Link
            href="/events"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Browse Events
          </Link>
          {isLoggedIn && (
            <>
              <Link
                href="/tickets"
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                My Tickets
              </Link>
              {userRole === 'admin' && (
                <Link
                  href="/admin"
                  className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
                >
                  Admin Dashboard
                </Link>
              )}
            </>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {!isLoggedIn ? (
            <>
              <Button
                variant="ghost"
                className="hidden sm:inline-flex"
                onClick={() => setIsLoggedIn(true)}
              >
                Login
              </Button>
              <Button className="hidden sm:inline-flex">Sign Up</Button>
            </>
          ) : (
            <Button variant="outline" onClick={() => setIsLoggedIn(false)}>
              Logout
            </Button>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="border-t bg-background px-4 py-4 md:hidden">
          <div className="space-y-3">
            <Link
              href="/events"
              className="block text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Browse Events
            </Link>
            {isLoggedIn && (
              <>
                <Link
                  href="/tickets"
                  className="block text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
                >
                  My Tickets
                </Link>
                {userRole === 'admin' && (
                  <Link
                    href="/admin"
                    className="block text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Admin Dashboard
                  </Link>
                )}
              </>
            )}
            {!isLoggedIn && (
              <>
                <Button variant="ghost" className="w-full" onClick={() => setIsLoggedIn(true)}>
                  Login
                </Button>
                <Button className="w-full">Sign Up</Button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
