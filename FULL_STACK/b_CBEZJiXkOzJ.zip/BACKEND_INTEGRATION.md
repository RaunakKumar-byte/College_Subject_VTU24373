# Backend Integration Guide

Complete guide to integrate the EventHub backend with the frontend application.

## Overview

The EventHub application consists of:
- **Frontend**: Next.js application (port 3000)
- **Backend**: Node.js/Express server (port 5000)
- **Database**: MongoDB

## Step 1: Setup MongoDB

### Option A: Local MongoDB

```bash
# Install MongoDB Community Edition
# https://docs.mongodb.com/manual/installation/

# Start MongoDB server
mongod

# Create database and user
mongosh
> use eventhub
> db.createUser({
    user: "admin",
    pwd: "password",
    roles: ["readWrite"]
  })
```

### Option B: MongoDB Atlas (Cloud)

1. Sign up at https://www.mongodb.com/cloud/atlas
2. Create a cluster
3. Get connection string: `mongodb+srv://username:password@cluster.mongodb.net/eventhub`
4. Use this in MONGODB_URI

## Step 2: Setup Email Service

### Gmail Configuration

1. Enable 2FA on your Gmail account
2. Generate app password at https://myaccount.google.com/apppasswords
3. Update `.env`:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_16_char_app_password
FROM_EMAIL=noreply@eventhub.com
FROM_NAME=EventHub
```

### Alternative: SendGrid, AWS SES, etc.

Modify `backend/services/emailService.js` to use your preferred service.

## Step 3: Setup Groq AI

1. Sign up at https://console.groq.com
2. Create an API key
3. Update `.env`:

```env
GROQ_API_KEY=your_groq_api_key
```

## Step 4: Setup Google Maps

1. Get API key from https://developers.google.com/maps
2. Enable Maps JavaScript API
3. Update frontend `.env.local`:

```env
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

## Step 5: Run Backend Server

```bash
cd backend
pnpm install
cp .env.example .env

# Update .env with your configuration

pnpm dev
# Server runs on http://localhost:5000
```

## Step 6: Update Frontend Configuration

Create `.env.local` in the frontend root:

```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_SOCKET_URL=http://localhost:5000
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_key_here
```

## Step 7: Run Frontend

```bash
pnpm dev
# App runs on http://localhost:3000
```

## Features Integration

### 1. Authentication Flow

```
User Registration/Login
    ↓
Backend validates credentials
    ↓
Generate JWT token
    ↓
Store token in localStorage
    ↓
Use token in Authorization header for API calls
```

**Code Example:**

```typescript
// Login
const response = await apiClient.login(email, password)
const token = response.token
const user = response.user

// Use in requests (automatic via interceptor)
const events = await apiClient.getEvents()
```

### 2. OTP Verification Flow

```
User fills booking form
    ↓
User selects OTP method (Email/Phone)
    ↓
User clicks "Proceed to Payment"
    ↓
Frontend shows OTP modal
    ↓
Backend sends OTP via selected method
    ↓
User enters OTP
    ↓
Backend verifies OTP
    ↓
Booking is confirmed
```

**Code Example:**

```typescript
// In booking form
const handleBookingSubmit = (data) => {
  setShowOTPVerification(true)
}

// In OTP modal
const handleOTPSuccess = async () => {
  await apiClient.createBooking(bookingData)
}
```

### 3. Real-time Seat Updates

```
User opens event page
    ↓
Frontend connects to Socket.IO
    ↓
Frontend joins event room
    ↓
When seat is booked elsewhere:
  - Backend emits 'seats-updated' event
  - Frontend receives update
  - UI refreshes seat availability
```

**Code Example:**

```typescript
import { socketService } from '@/lib/socket-service'

useEffect(() => {
  socketService.connect(token).then(() => {
    socketService.joinEvent(eventId)
    socketService.onSeatsUpdated(eventId, (data) => {
      // Update UI with new seat data
    })
  })
}, [eventId])
```

### 4. Email Notifications

Automatic emails sent for:
- Booking confirmations
- Event reminders (24 hours before)
- Cancellation notices

**Backend Configuration:**

```typescript
// In booking creation
await sendBookingConfirmation(user, booking, event)
```

### 5. Chatbot Integration

```
User opens chatbot widget
    ↓
User types message
    ↓
Frontend sends to backend
    ↓
Backend sends to Groq AI API
    ↓
AI generates response
    ↓
Response displayed in chat
```

**Code Example:**

```typescript
const response = await apiClient.sendChatMessage(userMessage, eventId)
```

### 6. Google Maps Display

```
Event details page loads
    ↓
Venue map component displays
    ↓
Shows venue location and details
    ↓
User can click "Get Directions"
    ↓
Opens Google Maps in new tab
```

**Code Example:**

```typescript
<VenueMap venue={event.venue} />
```

## API Call Examples

### Register User

```typescript
await apiClient.register({
  firstName: 'John',
  lastName: 'Doe',
  email: 'john@example.com',
  phone: '9876543210',
  password: 'password123',
  passwordConfirm: 'password123',
})
```

### Get Events

```typescript
const response = await apiClient.getEvents({
  category: 'concert',
  city: 'Delhi',
  search: 'music',
})
```

### Create Booking

```typescript
await apiClient.createBooking({
  eventId: 'event_id',
  seats: ['A1', 'A2'],
  customerName: 'John Doe',
  customerEmail: 'john@example.com',
  customerPhone: '9876543210',
  otpVerified: true,
  otpMethod: 'email',
})
```

### Send OTP

```typescript
await apiClient.sendOTP('email', 'booking')
```

### Verify OTP

```typescript
await apiClient.verifyOTP('123456', 'email', 'booking')
```

### Send Chat Message

```typescript
const response = await apiClient.sendChatMessage(
  'When is the event?',
  eventId
)
```

## Troubleshooting

### Backend Connection Issues

**Problem**: "Cannot POST /api/auth/login"

**Solution**:
1. Ensure backend is running on port 5000
2. Check `NEXT_PUBLIC_API_URL` in frontend .env
3. Verify CORS is enabled in backend

### Email Not Sending

**Problem**: OTP not received in email

**Solution**:
1. Check SMTP credentials in backend .env
2. If using Gmail, verify app password (not regular password)
3. Check spam/promotions folder
4. Check server logs for errors

### OTP Not Working

**Problem**: "Invalid OTP" error

**Solution**:
1. Ensure OTP hasn't expired (5 minutes default)
2. Check if backend email is actually sending
3. Verify user is entering correct OTP
4. Check rate limiting (3 attempts per minute)

### Socket.IO Connection Issues

**Problem**: Real-time updates not working

**Solution**:
1. Ensure backend Socket.IO is running
2. Check `NEXT_PUBLIC_SOCKET_URL` matches backend URL
3. Verify CORS configuration in backend server.js
4. Check browser console for connection errors

### Chatbot Not Responding

**Problem**: AI responses not working

**Solution**:
1. Verify GROQ_API_KEY is set in backend .env
2. Check Groq API key is valid and not expired
3. Monitor API rate limits
4. Check backend logs for errors

## Development Tips

### Enable Debug Logging

Frontend:
```typescript
// In components
console.log('[v0] Debug info:', data)
```

Backend:
```javascript
// In routes
console.log('[DEBUG] Event created:', event)
```

### Test OTP Locally

Backend console will print OTP:
```
[SMS] OTP to 9876543210: 123456
```

### Mock API Responses

For testing without backend:
```typescript
// Modify api-client.ts to return mock data
const mockResponse = {
  success: true,
  events: [...]
}
```

## Production Deployment

### Backend (Heroku Example)

```bash
cd backend
heroku create eventhub-backend
git push heroku main
```

Set environment variables:
```bash
heroku config:set MONGODB_URI=your_atlas_uri
heroku config:set JWT_SECRET=your_secret
heroku config:set GROQ_API_KEY=your_key
```

### Frontend (Vercel)

```bash
vercel deploy
```

Update environment variables in Vercel dashboard:
```
NEXT_PUBLIC_API_URL=https://eventhub-backend.herokuapp.com/api
NEXT_PUBLIC_SOCKET_URL=https://eventhub-backend.herokuapp.com
```

## Database Migrations

To seed initial data:

```bash
# Run seed script
node backend/scripts/seed.js
```

## Security Checklist

- [ ] Change JWT_SECRET to a strong value
- [ ] Use HTTPS in production
- [ ] Set CORS to only allow your domain
- [ ] Use strong database password
- [ ] Enable MongoDB authentication
- [ ] Set rate limiting appropriately
- [ ] Use environment variables (not hardcoded)
- [ ] Validate all inputs on backend
- [ ] Enable CSRF protection
- [ ] Regular security updates

## Next Steps

1. Set up all external services (MongoDB, Email, Groq, Maps)
2. Run backend and frontend in development
3. Test all features end-to-end
4. Set up CI/CD pipeline
5. Deploy to production
6. Monitor and maintain

## Support Resources

- Backend Docs: `/backend/README.md`
- API Documentation: Backend API endpoints section
- Frontend Setup: Root README.md
- Issue Tracking: GitHub Issues

## Contact

For integration issues or questions, please refer to the documentation or create an issue.
