'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { EventCard } from '@/components/shared/event-card'
import { useEvents } from '@/hooks/useEvents'
import { useBookings } from '@/hooks/useBookings'
import { EVENT_CATEGORIES } from '@/lib/constants'
import { EventCategory } from '@/lib/types'
import { formatDate, formatPrice } from '@/lib/utils'
import { Calendar, MapPin, Ticket, Users, ArrowRight } from 'lucide-react'

export default function UserPage() {
  const { events: filteredEvents, filterEvents } = useEvents()
  const userId = 'user-123' // Will be replaced with actual user ID from auth
  const { getUserBookings } = useBookings()

  const userBookings = getUserBookings(userId)
  const [selectedCategory, setSelectedCategory] = useState<EventCategory | 'All'>('All')

  const handleCategoryFilter = (category: string) => {
    const cat = category as EventCategory | 'All'
    setSelectedCategory(cat)
    filterEvents({
      category: cat,
      sortBy: 'date',
    })
  }

  const upcomingBookings = userBookings.filter((b) => b.status === 'Confirmed')
  const totalSpent = upcomingBookings.reduce((sum, b) => sum + b.totalPrice, 0)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary/10 to-background border-b px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h1 className="text-3xl font-bold text-foreground sm:text-4xl">My Dashboard</h1>
          <p className="mt-2 text-lg text-muted-foreground">Manage your bookings and discover new events</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <Tabs defaultValue="bookings" className="space-y-6">
            <TabsList>
              <TabsTrigger value="bookings">
                <Ticket className="h-4 w-4 mr-2" />
                My Bookings
              </TabsTrigger>
              <TabsTrigger value="discover">
                <Calendar className="h-4 w-4 mr-2" />
                Discover Events
              </TabsTrigger>
            </TabsList>

            {/* Bookings Tab */}
            <TabsContent value="bookings" className="space-y-6">
              {/* Summary Cards */}
              {upcomingBookings.length > 0 && (
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{upcomingBookings.length}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium">Total Tickets</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {upcomingBookings.reduce((sum, b) => sum + b.quantity, 0)}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-primary">{formatPrice(totalSpent)}</div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Bookings List */}
              {upcomingBookings.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Ticket className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-lg text-foreground font-medium mb-2">No bookings yet</p>
                    <p className="text-muted-foreground mb-6">
                      Start exploring events and book your first ticket!
                    </p>
                    <Link href="/events">
                      <Button>Browse Events</Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {upcomingBookings.map((booking) => {
                    // Note: In a real app, we'd fetch the event details
                    return (
                      <Card key={booking.id}>
                        <CardContent className="pt-6">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-foreground mb-2">Booking #{booking.ticketNumber.slice(-8)}</h3>
                              <div className="space-y-1 text-sm text-muted-foreground">
                                <p>Confirmation: {booking.confirmationCode}</p>
                                <p>{booking.quantity} ticket(s)</p>
                                <p>Total: {formatPrice(booking.totalPrice)}</p>
                              </div>
                            </div>
                            <Link href={`/booking/confirmation/${booking.id}`}>
                              <Button variant="outline">View Details</Button>
                            </Link>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              )}
            </TabsContent>

            {/* Discover Tab */}
            <TabsContent value="discover" className="space-y-6">
              {/* Category Filter */}
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === 'All' ? 'default' : 'outline'}
                  onClick={() => handleCategoryFilter('All')}
                >
                  All
                </Button>
                {EVENT_CATEGORIES.map((cat) => (
                  <Button
                    key={cat.value}
                    variant={selectedCategory === cat.value ? 'default' : 'outline'}
                    onClick={() => handleCategoryFilter(cat.value)}
                  >
                    {cat.icon} {cat.label}
                  </Button>
                ))}
              </div>

              {/* Events Grid */}
              {filteredEvents.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-lg text-foreground font-medium">No events found</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredEvents.map((event) => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
