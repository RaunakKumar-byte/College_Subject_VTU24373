'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { useBookings } from '@/hooks/useBookings'
import { useEvents } from '@/hooks/useEvents'
import { formatDate, formatTime, formatPrice } from '@/lib/utils'
import { toast } from 'sonner'
import { Ticket, Calendar, MapPin, MoreVertical, Trash2, Download, Copy } from 'lucide-react'

export default function TicketsPage() {
  const userId = 'user-123' // Will be replaced with actual user ID from auth
  const { getUserBookings, cancelBooking } = useBookings()
  const { getEventById } = useEvents()
  const [cancelllingId, setCancellingId] = useState<string | null>(null)

  const bookings = getUserBookings(userId)

  const handleCancelBooking = async (bookingId: string) => {
    try {
      setCancellingId(bookingId)
      await cancelBooking(bookingId)
      toast.success('Booking cancelled successfully')
    } catch (error) {
      toast.error('Failed to cancel booking')
    } finally {
      setCancellingId(null)
    }
  }

  const handleCopyTicket = (ticketNumber: string) => {
    navigator.clipboard.writeText(ticketNumber)
    toast.success('Ticket number copied!')
  }

  if (bookings.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <Ticket className="mx-auto h-16 w-16 text-muted-foreground" />
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">No Tickets Yet</h1>
              <p className="text-lg text-muted-foreground">
                You haven&apos;t booked any tickets yet. Start exploring events!
              </p>
            </div>
            <Link href="/events">
              <Button size="lg">Browse Events</Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary/10 to-background px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h1 className="text-3xl font-bold text-foreground sm:text-4xl">My Tickets</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            {bookings.length} booking{bookings.length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Tickets List */}
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl space-y-6">
          {bookings.map((booking) => {
            const event = getEventById(booking.eventId)

            if (!event) return null

            return (
              <Card key={booking.id} className="overflow-hidden">
                <CardContent className="pt-6">
                  <div className="grid gap-6 md:grid-cols-3">
                    {/* Left: Event Info */}
                    <div className="md:col-span-2 space-y-4">
                      <div>
                        <h3 className="text-xl font-bold text-foreground mb-2">{event.title}</h3>
                        <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
                          {event.category}
                        </span>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>
                            {formatDate(event.startDate)} at {formatTime(event.startDate)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          <span>{event.location}</span>
                        </div>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-foreground mb-2">Your Seats</p>
                        <div className="flex flex-wrap gap-2">
                          {booking.seatNumbers.map((seat) => (
                            <span
                              key={seat}
                              className="bg-primary text-primary-foreground px-3 py-1 rounded-lg text-sm font-medium"
                            >
                              {seat}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Right: Ticket Details & Actions */}
                    <div className="space-y-4">
                      {/* Status Badge */}
                      <div>
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                            booking.status === 'Confirmed'
                              ? 'bg-green-100 text-green-700'
                              : booking.status === 'Pending'
                                ? 'bg-yellow-100 text-yellow-700'
                                : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {booking.status}
                        </span>
                      </div>

                      {/* Ticket Number */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Ticket Number</p>
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono bg-muted rounded px-2 py-1 flex-1 truncate">
                            {booking.ticketNumber}
                          </code>
                          <button
                            onClick={() => handleCopyTicket(booking.ticketNumber)}
                            className="text-primary hover:text-primary/80"
                          >
                            <Copy className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      {/* Confirmation Code */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Confirmation Code</p>
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono bg-muted rounded px-2 py-1 flex-1 truncate">
                            {booking.confirmationCode}
                          </code>
                          <button
                            onClick={() => handleCopyTicket(booking.confirmationCode)}
                            className="text-primary hover:text-primary/80"
                          >
                            <Copy className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      {/* Price */}
                      <div className="bg-muted rounded-lg p-3">
                        <p className="text-xs text-muted-foreground mb-1">Total Paid</p>
                        <p className="text-lg font-bold text-primary">{formatPrice(booking.totalPrice)}</p>
                      </div>

                      {/* Actions */}
                      <div className="space-y-2">
                        <Link href={`/booking/confirmation/${booking.id}`} className="block">
                          <Button variant="outline" className="w-full text-xs">
                            <Download className="h-3 w-3 mr-1" />
                            View Details
                          </Button>
                        </Link>

                        {booking.status === 'Confirmed' && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" className="w-full text-xs" size="sm">
                                <Trash2 className="h-3 w-3 mr-1" />
                                Cancel
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogTitle>Cancel Booking</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to cancel this booking? This action cannot be undone.
                              </AlertDialogDescription>
                              <div className="flex gap-3 justify-end">
                                <AlertDialogCancel>Keep It</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleCancelBooking(booking.id)}
                                  className="bg-destructive"
                                  disabled={cancelllingId === booking.id}
                                >
                                  {cancelllingId === booking.id ? 'Cancelling...' : 'Yes, Cancel'}
                                </AlertDialogAction>
                              </div>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}
