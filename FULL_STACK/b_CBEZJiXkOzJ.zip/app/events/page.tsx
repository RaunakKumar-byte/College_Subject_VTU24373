'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { EventCard } from '@/components/shared/event-card'
import { useEvents } from '@/hooks/useEvents'
import { EVENT_CATEGORIES } from '@/lib/constants'
import { EventCategory } from '@/lib/types'
import { Search, Loader2 } from 'lucide-react'

export default function EventsPage() {
  const { events, filteredEvents, loading, filterEvents } = useEvents()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<EventCategory | 'All'>('All')
  const [sortBy, setSortBy] = useState<'date' | 'price' | 'popularity'>('date')

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    filterEvents({
      category: selectedCategory,
      searchQuery: query,
      sortBy,
    })
  }

  const handleCategoryChange = (category: string) => {
    const cat = category as EventCategory | 'All'
    setSelectedCategory(cat)
    filterEvents({
      category: cat,
      searchQuery,
      sortBy,
    })
  }

  const handleSortChange = (sort: string) => {
    setSortBy(sort as 'date' | 'price' | 'popularity')
    filterEvents({
      category: selectedCategory,
      searchQuery,
      sortBy: sort as 'date' | 'price' | 'popularity',
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary/10 to-background px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h1 className="text-3xl font-bold text-foreground sm:text-4xl mb-8">Browse Events</h1>

          {/* Filters */}
          <div className="space-y-4 lg:space-y-0 lg:flex lg:gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search events by name, location..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={handleCategoryChange}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Categories</SelectItem>
                {EVENT_CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.icon} {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="w-full lg:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Nearest Date</SelectItem>
                <SelectItem value="price">Price: Low to High</SelectItem>
                <SelectItem value="popularity">Most Popular</SelectItem>
              </SelectContent>
            </Select>

            {/* Reset Button */}
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery('')
                setSelectedCategory('All')
                setSortBy('date')
                filterEvents({ category: 'All', searchQuery: '', sortBy: 'date' })
              }}
            >
              Reset
            </Button>
          </div>
        </div>
      </div>

      {/* Events Grid */}
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          {loading ? (
            <div className="flex justify-center items-center h-96">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredEvents.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground">No events found matching your criteria</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchQuery('')
                  setSelectedCategory('All')
                  setSortBy('date')
                  filterEvents({ category: 'All', searchQuery: '', sortBy: 'date' })
                }}
                className="mt-4"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <>
              <p className="mb-6 text-sm text-muted-foreground">
                Showing {filteredEvents.length} event{filteredEvents.length !== 1 ? 's' : ''}
              </p>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredEvents.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
