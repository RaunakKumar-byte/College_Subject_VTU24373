'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ArrowRight, Music, Zap, Users, Shield } from 'lucide-react'

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-background to-background px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
                  Discover & Book Your <span className="text-primary">Perfect Event</span>
                </h1>
                <p className="text-xl text-muted-foreground">
                  From concerts and workshops to seminars and social events - find and book tickets to amazing experiences happening near you.
                </p>
              </div>
              <div className="flex flex-col gap-4 sm:flex-row">
                <Link href="/events">
                  <Button size="lg" className="w-full sm:w-auto">
                    Browse Events
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Learn More
                </Button>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative h-96 rounded-lg overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&h=400&fit=crop"
                alt="Event"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl">Why Choose EventHub?</h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Experience seamless event booking with our platform
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: Music,
                title: 'Diverse Events',
                description: 'Explore concerts, workshops, seminars, webinars, and social events',
              },
              {
                icon: Zap,
                title: 'Instant Booking',
                description: 'Quick and secure ticket booking with real-time seat selection',
              },
              {
                icon: Users,
                title: 'Easy Management',
                description: 'Manage your bookings and tickets all in one place',
              },
              {
                icon: Shield,
                title: 'Secure Payment',
                description: 'Multiple payment options with secure transaction processing',
              },
            ].map((feature, index) => {
              const Icon = feature.icon
              return (
                <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
                  <Icon className="mx-auto h-12 w-12 text-primary mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-20 sm:px-6 lg:px-8 bg-primary/5">
        <div className="mx-auto max-w-7xl text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Ready to Find Your Next Event?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start exploring amazing events and book your tickets today
          </p>
          <Link href="/events">
            <Button size="lg">
              Explore Events
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
