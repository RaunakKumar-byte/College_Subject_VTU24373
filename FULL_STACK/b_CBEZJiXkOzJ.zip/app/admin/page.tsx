'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { EventForm } from '@/components/admin/event-form'
import { EventList } from '@/components/admin/event-list'
import { AnalyticsDashboard } from '@/components/admin/analytics-dashboard'
import { useEvents } from '@/hooks/useEvents'
import { EventCreateInput } from '@/lib/validation'
import { Event } from '@/lib/types'
import { toast } from 'sonner'
import { Plus } from 'lucide-react'

export default function AdminPage() {
  const { allEvents, createEvent, updateEvent, deleteEvent } = useEvents()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingEvent, setEditingEvent] = useState<Event | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleCreateEvent = async (data: EventCreateInput) => {
    try {
      setIsSubmitting(true)
      await createEvent({
        ...data,
        totalSeats: data.capacity,
        availableSeats: data.capacity,
        organizerId: 'org-admin', // Will be replaced with actual admin ID
      })
      toast.success('Event created successfully!')
      setIsDialogOpen(false)
    } catch (error) {
      toast.error('Failed to create event')
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateEvent = async (data: EventCreateInput) => {
    if (!editingEvent) return

    try {
      setIsSubmitting(true)
      await updateEvent(editingEvent.id, {
        ...data,
        totalSeats: data.capacity,
      })
      toast.success('Event updated successfully!')
      setIsDialogOpen(false)
      setEditingEvent(null)
    } catch (error) {
      toast.error('Failed to update event')
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteEvent = async (eventId: string) => {
    try {
      await deleteEvent(eventId)
      toast.success('Event deleted successfully!')
    } catch (error) {
      toast.error('Failed to delete event')
      console.error(error)
    }
  }

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event)
    setIsDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setEditingEvent(null)
    setIsSubmitting(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-b from-primary/10 to-background border-b px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground sm:text-4xl">Admin Dashboard</h1>
              <p className="mt-2 text-lg text-muted-foreground">Manage events and view analytics</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <Tabs defaultValue="overview" className="space-y-6">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="events">Events</TabsTrigger>
              </TabsList>
              <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Event
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingEvent ? 'Edit Event' : 'Create New Event'}
                    </DialogTitle>
                    <DialogDescription>
                      {editingEvent
                        ? 'Update the event details below'
                        : 'Fill in the details to create a new event'}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="mt-6">
                    <EventForm
                      onSubmit={editingEvent ? handleUpdateEvent : handleCreateEvent}
                      isLoading={isSubmitting}
                      submitButtonText={editingEvent ? 'Update Event' : 'Create Event'}
                    />
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Overview Tab */}
            <TabsContent value="overview">
              <AnalyticsDashboard />
            </TabsContent>

            {/* Events Tab */}
            <TabsContent value="events" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Events Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <EventList
                    events={allEvents}
                    onDelete={handleDeleteEvent}
                    onEdit={handleEditEvent}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
