'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useParams, useRouter } from 'next/navigation'
import { SeatSelector } from '@/components/booking/seat-selector'
import { BookingForm } from '@/components/booking/booking-form'
import { OTPVerification } from '@/components/booking/otp-verification'
import { VenueMap } from '@/components/events/venue-map'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useEvents } from '@/hooks/useEvents'
import { useBookings } from '@/hooks/useBookings'
import { BookingInput } from '@/lib/validation'
import { formatPrice, formatDate, formatTime } from '@/lib/utils'
import { toast } from 'sonner'
import { ArrowLeft, Loader2, Calendar, MapPin, Users, Lock } from 'lucide-react'

export default function BookingPage() {
  const params = useParams()
  const router = useRouter()
  const eventId = params.eventId as string

  const { getEventById } = useEvents()
  const { createBooking } = useBookings()
  const event = getEventById(eventId)

  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showOTPVerification, setShowOTPVerification] = useState(false)
  const [otpMethod, setOTPMethod] = useState<'email' | 'phone'>('email')
  const [bookingData, setBookingData] = useState<BookingInput | null>(null)

  if (!event) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Event not found</h1>
          <p className="text-muted-foreground">The event you&apos;re looking for doesn&apos;t exist.</p>
          <Link href="/events">
            <Button>Browse Events</Button>
          </Link>
        </div>
      </div>
    )
  }

  const totalPrice = selectedSeats.length * event.ticketPrice

  const handleBookingSubmit = async (data: BookingInput) => {
    if (selectedSeats.length === 0) {
      toast.error('Please select at least one seat')
      return
    }

    // Store booking data and show OTP verification
    setBookingData(data)
    setShowOTPVerification(true)
  }

  const handleOTPSuccess = async () => {
    if (!bookingData) return

    try {
      setIsSubmitting(true)
      const booking = await createBooking({
        eventId: event.id,
        userId: 'user-123', // Will be replaced with actual user ID from auth
        attendeeName: bookingData.attendeeName,
        attendeeEmail: bookingData.attendeeEmail,
        attendeePhone: bookingData.attendeePhone,
        seatNumbers: selectedSeats,
        quantity: selectedSeats.length,
        totalPrice,
        paymentMethod: bookingData.paymentMethod,
        status: 'Confirmed',
        otpVerified: true,
        otpMethod: otpMethod,
      })

      toast.success('Booking confirmed! Check your email for details.')
      setShowOTPVerification(false)
      router.push(`/booking/confirmation/${booking.id}`)
    } catch (error) {
      toast.error('Failed to create booking. Please try again.')
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link href="/events" className="inline-flex items-center gap-2 text-primary hover:text-primary/80">
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Events</span>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left: Seat Selection & Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Event Details */}
            <Card>
              <CardHeader>
                <CardTitle>{event.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>
                    {formatDate(event.startDate)} at {formatTime(event.startDate)}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{event.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>{event.availableSeats} seats available</span>
                </div>
              </CardContent>
            </Card>

            {/* Venue Map */}
            {event.venue && (
              <VenueMap venue={event.venue} />
            )}

            {/* Seat Selection */}
            <SeatSelector
              eventId={event.id}
              bookedSeats={[]}
              onSelectionChange={setSelectedSeats}
              maxSelectable={10}
            />

            {/* Booking Form */}
            {selectedSeats.length > 0 && (
              <BookingForm
                eventId={event.id}
                selectedSeats={selectedSeats}
                ticketPrice={event.ticketPrice}
                onSubmit={handleBookingSubmit}
                isLoading={isSubmitting}
                onOTPMethodChange={setOTPMethod}
              />
            )}

            {selectedSeats.length === 0 && (
              <Card className="bg-muted/50">
                <CardContent className="pt-6 text-center text-muted-foreground">
                  Please select at least one seat to continue
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right: Booking Summary */}
          <div>
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Event Info */}
                <div>
                  <p className="text-sm font-medium text-foreground mb-1">Event</p>
                  <p className="text-sm text-muted-foreground line-clamp-2">{event.title}</p>
                </div>

                {/* Seats Info */}
                <div>
                  <p className="text-sm font-medium text-foreground mb-1">Seats</p>
                  {selectedSeats.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {selectedSeats.map((seat) => (
                        <span key={seat} className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs">
                          {seat}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No seats selected</p>
                  )}
                </div>

                {/* Price Breakdown */}
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      {selectedSeats.length} Ticket{selectedSeats.length !== 1 ? 's' : ''}
                    </span>
                    <span className="font-medium">
                      {formatPrice(selectedSeats.length * event.ticketPrice)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Booking Fee</span>
                    <span className="font-medium">{formatPrice(0)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between">
                    <span className="font-semibold">Total Amount</span>
                    <span className="text-lg font-bold text-primary">{formatPrice(totalPrice)}</span>
                  </div>
                </div>

                {/* Info */}
                <p className="text-xs text-muted-foreground">
                  You will receive a confirmation email with your ticket details and QR code for entry.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* OTP Verification Modal */}
      {bookingData && (
        <OTPVerification
          isOpen={showOTPVerification}
          onClose={() => setShowOTPVerification(false)}
          onSuccess={handleOTPSuccess}
          email={bookingData.attendeeEmail}
          phone={bookingData.attendeePhone}
          method={otpMethod}
        />
      )}
    </div>
  )
}
