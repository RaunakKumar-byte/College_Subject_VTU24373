'use client'

import { useParams } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useBookings } from '@/hooks/useBookings'
import { useEvents } from '@/hooks/useEvents'
import { formatDate, formatTime, formatPrice } from '@/lib/utils'
import { Download, CheckCircle2, Copy } from 'lucide-react'
import { toast } from 'sonner'

export default function ConfirmationPage() {
  const params = useParams()
  const bookingId = params.bookingId as string

  const { getBookingById } = useBookings()
  const { getEventById } = useEvents()

  const booking = getBookingById(bookingId)
  const event = booking ? getEventById(booking.eventId) : null

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard!')
  }

  if (!booking || !event) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Booking not found</h1>
          <p className="text-muted-foreground">Unable to find your booking details.</p>
          <Link href="/events">
            <Button>Browse Events</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Success Message */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Booking Confirmed!</h1>
          <p className="text-lg text-muted-foreground">
            Your tickets have been sent to {booking.attendeeEmail}
          </p>
        </div>

        {/* Booking Details */}
        <div className="space-y-4 mb-8">
          {/* Confirmation Code */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Confirmation Code</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between bg-muted rounded-lg p-4">
                <code className="text-2xl font-mono font-bold">{booking.confirmationCode}</code>
                <button onClick={() => copyToClipboard(booking.confirmationCode)} className="text-primary">
                  <Copy className="h-5 w-5" />
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Event Information */}
          <Card>
            <CardHeader>
              <CardTitle>Event Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Event Name</p>
                <p className="text-lg font-semibold">{event.title}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Date & Time</p>
                <p className="font-medium">
                  {formatDate(event.startDate)} at {formatTime(event.startDate)}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Location</p>
                <p className="font-medium">{event.location}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Category</p>
                <p className="font-medium">{event.category}</p>
              </div>
            </CardContent>
          </Card>

          {/* Booking Information */}
          <Card>
            <CardHeader>
              <CardTitle>Booking Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Attendee Name</p>
                <p className="font-medium">{booking.attendeeName}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Email</p>
                <p className="font-medium">{booking.attendeeEmail}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Phone</p>
                <p className="font-medium">{booking.attendeePhone}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Selected Seats</p>
                <div className="flex flex-wrap gap-2">
                  {booking.seatNumbers.map((seat) => (
                    <span key={seat} className="bg-primary text-primary-foreground px-3 py-1 rounded text-sm">
                      {seat}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Payment Method</p>
                <p className="font-medium">{booking.paymentMethod}</p>
              </div>
            </CardContent>
          </Card>

          {/* Price Summary */}
          <Card className="bg-primary/5">
            <CardContent className="pt-6 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {booking.quantity} Ticket{booking.quantity !== 1 ? 's' : ''}
                </span>
                <span className="font-medium">{formatPrice(booking.totalPrice)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Booking Fee</span>
                <span className="font-medium">{formatPrice(0)}</span>
              </div>
              <div className="border-t pt-3 flex justify-between">
                <span className="font-semibold">Total Paid</span>
                <span className="text-lg font-bold text-primary">{formatPrice(booking.totalPrice)}</span>
              </div>
            </CardContent>
          </Card>

          {/* Ticket Number */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ticket Number</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between bg-muted rounded-lg p-4">
                <code className="text-sm font-mono">{booking.ticketNumber}</code>
                <button onClick={() => copyToClipboard(booking.ticketNumber)} className="text-primary">
                  <Copy className="h-5 w-5" />
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Important Information */}
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="text-lg text-orange-900">Important Information</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-orange-800 space-y-2">
              <p>✓ A detailed ticket with QR code has been sent to your email</p>
              <p>✓ Please bring a valid ID and your confirmation code to the venue</p>
              <p>✓ Arrive at least 15 minutes before the event starts</p>
              <p>✓ For any issues, contact the event organizer using your confirmation code</p>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3 sm:flex-row">
          <Link href="/tickets" className="flex-1">
            <Button className="w-full" variant="outline">
              View My Tickets
            </Button>
          </Link>
          <Link href="/events" className="flex-1">
            <Button className="w-full">
              Browse More Events
            </Button>
          </Link>
        </div>

        {/* Download Ticket */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">Check your email for your complete ticket</p>
          <Button variant="outline" size="lg" disabled>
            <Download className="mr-2 h-5 w-5" />
            Download Ticket (Coming Soon)
          </Button>
        </div>
      </div>
    </div>
  )
}
