# EventHub - Integration Guide

This guide shows how to integrate external services into EventHub.

## 🔐 Authentication

### Option 1: Supabase Auth (Recommended)

**Setup:**
```bash
pnpm add @supabase/supabase-js
```

**Update Header Component** (`components/shared/header.tsx`):
```typescript
'use client'

import { useEffect, useState } from 'react'
import { createBrowserClient } from '@supabase/ssr'

export function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState(null)
  
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  useEffect(() => {
    supabase.auth.onAuthStateChange((event, session) => {
      setIsLoggedIn(!!session)
      setUser(session?.user || null)
    })
  }, [])

  // ... rest of component
}
```

**Environment Variables:**
```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
```

### Option 2: NextAuth.js

**Setup:**
```bash
pnpm add next-auth
```

See: https://next-auth.js.org/getting-started/example

## 🗄️ Database Integration

### Option 1: Supabase (SQL)

**Setup:**
```bash
pnpm add @supabase/supabase-js
```

**Create Tables:**
```sql
-- Events Table
CREATE TABLE events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  start_date TIMESTAMP NOT NULL,
  end_date TIMESTAMP NOT NULL,
  duration INTEGER,
  location TEXT,
  capacity INTEGER,
  total_seats INTEGER,
  available_seats INTEGER,
  ticket_price DECIMAL,
  image TEXT,
  organizer_id UUID,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Bookings Table
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES events(id),
  user_id UUID,
  attendee_name TEXT NOT NULL,
  attendee_email TEXT NOT NULL,
  attendee_phone TEXT NOT NULL,
  seat_numbers TEXT[],
  quantity INTEGER,
  total_price DECIMAL,
  payment_method TEXT,
  status TEXT,
  booking_date TIMESTAMP DEFAULT NOW(),
  ticket_number TEXT UNIQUE,
  confirmation_code TEXT UNIQUE
);

-- Seats Table
CREATE TABLE seats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES events(id),
  seat_number TEXT,
  row TEXT,
  column INTEGER,
  is_booked BOOLEAN DEFAULT FALSE,
  booking_id UUID,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**Update useEvents Hook:**
```typescript
import { createBrowserClient } from '@supabase/ssr'

const supabase = createBrowserClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export function useEvents() {
  const [events, setEvents] = useState<Event[]>([])
  
  useEffect(() => {
    const fetchEvents = async () => {
      const { data, error } = await supabase
        .from('events')
        .select('*')
      
      if (data) setEvents(data)
    }
    
    fetchEvents()
  }, [])
  
  // ... rest of hook
}
```

### Option 2: Neon (PostgreSQL)

**Setup:**
```bash
pnpm add @neondatabase/serverless
```

**Connection:**
```typescript
import { sql } from '@neondatabase/serverless'

const events = await sql('SELECT * FROM events')
```

### Option 3: Firebase (NoSQL)

**Setup:**
```bash
pnpm add firebase
```

**Initialize:**
```typescript
import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

const firebaseApp = initializeApp({
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  // ... other config
})

const db = getFirestore(firebaseApp)
```

## 📧 Email Integration

### Option 1: Resend (Recommended)

**Setup:**
```bash
pnpm add resend
```

**Environment Variable:**
```
RESEND_API_KEY=re_xxxxxxxxxxxxx
```

**Update Email Service** (`lib/email-service.ts`):
```typescript
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

private static async sendEmail(
  to: string, 
  subject: string, 
  html: string
): Promise<void> {
  try {
    await resend.emails.send({
      from: 'noreply@eventhub.com',
      to,
      subject,
      html,
    })
  } catch (error) {
    console.error('Failed to send email:', error)
    throw error
  }
}
```

### Option 2: SendGrid

**Setup:**
```bash
pnpm add @sendgrid/mail
```

**Configuration:**
```typescript
import sgMail from '@sendgrid/mail'

sgMail.setApiKey(process.env.SENDGRID_API_KEY!)

private static async sendEmail(
  to: string,
  subject: string,
  html: string
): Promise<void> {
  await sgMail.send({
    to,
    from: 'noreply@eventhub.com',
    subject,
    html,
  })
}
```

### Option 3: AWS SES

**Setup:**
```bash
pnpm add @aws-sdk/client-ses
```

See: https://docs.aws.amazon.com/ses/latest/APIReference/

## 💳 Payment Integration

### Option 1: Stripe

**Setup:**
```bash
pnpm add stripe @stripe/react-stripe-js
```

**Environment Variables:**
```
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
```

**Create Payment Route** (`app/api/create-payment-intent.ts`):
```typescript
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(req: Request) {
  const { amount, bookingId } = await req.json()

  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(amount * 100), // Convert to cents
    currency: 'inr',
    metadata: { bookingId },
  })

  return Response.json({ clientSecret: paymentIntent.client_secret })
}
```

**Update Booking Form:**
```typescript
import { Elements, CardElement, useStripe } from '@stripe/react-stripe-js'

const stripe = useStripe()
const elements = useElements()

const handlePayment = async () => {
  const result = await stripe?.confirmCardPayment(clientSecret, {
    payment_method: {
      card: elements?.getElement(CardElement)!,
    },
  })
}
```

### Option 2: Razorpay

**Setup:**
```bash
pnpm add razorpay
```

**Create Order Route:**
```typescript
import Razorpay from 'razorpay'

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
})

export async function POST(req: Request) {
  const { amount, bookingId } = await req.json()

  const order = await razorpay.orders.create({
    amount: Math.round(amount * 100), // Amount in paise
    currency: 'INR',
    receipt: bookingId,
  })

  return Response.json(order)
}
```

## 🖼️ File Storage

### Option 1: Vercel Blob

**Setup:**
```bash
pnpm add @vercel/blob
```

**Upload File:**
```typescript
import { put } from '@vercel/blob'

const blob = await put('events/image.jpg', file, {
  access: 'public',
})
```

### Option 2: AWS S3

**Setup:**
```bash
pnpm add @aws-sdk/client-s3
```

See: https://docs.aws.amazon.com/s3/latest/userguide/

### Option 3: Supabase Storage

**Upload:**
```typescript
const { data, error } = await supabase.storage
  .from('events')
  .upload(`${Date.now()}.jpg`, file)
```

## 📊 Analytics

### Option 1: PostHog

**Setup:**
```bash
pnpm add posthog-js
```

**Initialize:**
```typescript
import posthog from 'posthog-js'

posthog.init(process.env.NEXT_PUBLIC_POSTHOG_KEY!, {
  api_host: 'https://app.posthog.com',
})
```

### Option 2: Google Analytics

**Setup:**
```bash
pnpm add @react-google-analytics/core
```

### Option 3: Sentry (Error Tracking)

**Setup:**
```bash
pnpm add @sentry/nextjs
```

See: https://docs.sentry.io/platforms/javascript/guides/nextjs/

## 🔄 Workflow: Complete Integration

### 1. Setup Auth
- [ ] Choose auth provider (Supabase Auth recommended)
- [ ] Update Header component
- [ ] Add protected routes

### 2. Setup Database
- [ ] Choose database (Neon/Supabase recommended)
- [ ] Create tables
- [ ] Update hooks to fetch from database
- [ ] Replace mock data

### 3. Setup Email
- [ ] Choose email service (Resend recommended)
- [ ] Add API key to env vars
- [ ] Update email-service.ts
- [ ] Test booking confirmation emails

### 4. Setup Payments
- [ ] Choose payment provider (Stripe recommended)
- [ ] Create payment intent endpoint
- [ ] Update booking form
- [ ] Add payment confirmation

### 5. Setup File Storage
- [ ] Choose storage (Vercel Blob recommended)
- [ ] Update event image upload
- [ ] Add ticket PDF generation

### 6. Deploy
- [ ] Add env vars to production
- [ ] Test all integrations
- [ ] Monitor with analytics/Sentry

## 📝 Environment Variables Checklist

```
# Authentication
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
NEXTAUTH_SECRET=
NEXTAUTH_URL=

# Database
DATABASE_URL=

# Email
RESEND_API_KEY=
# or
SENDGRID_API_KEY=

# Payments
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
# or
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=

# Analytics
NEXT_PUBLIC_POSTHOG_KEY=
SENTRY_AUTH_TOKEN=
```

## 🧪 Testing Integrations

### Local Testing
1. Create `.env.local` with all keys
2. Test features locally
3. Check console for errors

### Staging Testing
1. Deploy to staging environment
2. Test full workflows
3. Monitor for production readiness

### Production Verification
1. Use test mode first
2. Monitor for errors
3. Have rollback plan ready

## 📚 Resources

- [Supabase Docs](https://supabase.io/docs)
- [Neon Docs](https://neon.tech/docs)
- [Resend Docs](https://resend.com/docs)
- [Stripe Docs](https://stripe.com/docs)
- [Next.js Integrations](https://nextjs.org/docs)

---

**Last Updated**: May 2024
