# EventHub - Advanced Features Documentation

Complete documentation of all advanced features implemented in the EventHub ticket booking system.

## Table of Contents

1. [OTP Verification System](#otp-verification-system)
2. [Email Notifications](#email-notifications)
3. [AI-Powered Chatbot](#ai-powered-chatbot)
4. [Google Maps Integration](#google-maps-integration)
5. [Real-time Updates](#real-time-updates)
6. [Architecture Overview](#architecture-overview)

## OTP Verification System

### Overview

Two-factor verification system for securing booking confirmations using One-Time Passwords.

### Features

1. **Dual Delivery Methods**
   - Email-based OTP
   - SMS-based OTP (Phone)
   - User can choose preferred method

2. **Security Features**
   - 6-digit random OTP
   - 5-minute expiration time
   - Rate limiting (3 requests per minute)
   - Maximum 3 verification attempts
   - Automatic cleanup of expired OTPs

3. **User Experience**
   - Modal dialog for OTP entry
   - Real-time countdown timer
   - Resend OTP option
   - Method switching option
   - Clear error messages

### Implementation Details

**Backend Models:**
```javascript
OTP {
  user: ObjectId (ref: User)
  code: String (6 digits)
  method: 'email' | 'phone'
  destination: String (email or phone)
  isVerified: Boolean
  attempts: Number (0-3)
  expiresAt: Date (5 minutes from creation)
  purpose: 'booking' | 'verification' | 'password_reset'
}
```

**API Endpoints:**

1. `POST /api/otp/send`
   - Send OTP via email or phone
   - Rate limited: 3 per minute
   - Returns: method and destination (masked)

2. `POST /api/otp/verify`
   - Verify OTP code
   - Increments attempts on failure
   - Returns: success or error message

3. `POST /api/otp/resend`
   - Resend OTP to same destination
   - Rate limited: 1 per minute
   - Returns: OTP sent confirmation

**Frontend Components:**

```typescript
<OTPVerification
  isOpen={boolean}
  onClose={() => void}
  onSuccess={() => void}
  email={string}
  phone={string}
  method={'email' | 'phone'}
/>
```

### Booking Flow with OTP

```
User fills booking form
    ↓
Selects OTP method (Email/Phone)
    ↓
Clicks "Proceed to Payment"
    ↓
OTP modal opens
    ↓
Backend sends OTP via selected method
    ↓
User enters OTP (6 digits)
    ↓
Frontend verifies with backend
    ↓
If successful: Complete booking
    ↓
If failed: Show error, allow retry (max 3 times)
```

### Configuration

**Backend (.env):**
```env
OTP_EXPIRY_TIME=300000 # 5 minutes in milliseconds
OTP_LENGTH=6
MAX_OTP_ATTEMPTS=3
RATE_LIMIT_WINDOW=60000 # 1 minute
```

## Email Notifications

### Overview

Comprehensive email notification system for booking confirmations, reminders, and cancellations.

### Features

1. **Automated Emails**
   - Booking confirmation (immediate)
   - Event reminders (24 hours before)
   - Cancellation notice (immediate)

2. **Email Services**
   - Nodemailer (SMTP - Gmail, SendGrid, etc.)
   - EmailJS API (alternative)
   - Fallback mechanism

3. **Template System**
   - HTML email templates
   - Personalization (user name, event details)
   - Professional formatting
   - Mobile-responsive

### Booking Confirmation Email

**Sent:** Immediately after OTP verification

**Contents:**
- Event title, date, time, venue
- Booking confirmation code
- Ticket numbers
- Total amount paid
- Seat details
- Booking reference

**Example:**
```html
Subject: Booking Confirmed - Summer Music Festival

Dear John,

Your booking is confirmed!

Event: Summer Music Festival
Date: July 15, 2024
Time: 6:00 PM
Venue: Grand Arena, Delhi

Confirmation Code: ABC123XYZ
Tickets: TKT-1234567890-ABC, TKT-1234567890-DEF
Total Amount: Rs. 1,000

Please keep this confirmation email safe. You'll need the 
confirmation code at the venue for entry.
```

### Event Reminder Email

**Sent:** 24 hours before event

**Contents:**
- Friendly reminder
- Event details
- Venue information
- Ticket attachment

### Cancellation Email

**Sent:** Immediately after cancellation

**Contents:**
- Cancellation confirmation
- Refund amount
- Refund timeline (5-7 business days)
- Cancellation reason (optional)

### Implementation

**Email Service:**
```typescript
// Send booking confirmation
await sendBookingConfirmation(user, booking, event)

// Send reminder
await sendBookingReminder(user, event)

// Send cancellation
await sendCancellationEmail(user, booking, event)
```

**API Endpoint:**
```
POST /api/email/send-confirmation
{
  bookingId: string
}

POST /api/email/send-reminder
{
  eventId: string
}

POST /api/email/send-cancellation
{
  bookingId: string
}
```

### Configuration

**Backend (.env):**
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
FROM_EMAIL=noreply@eventhub.com
FROM_NAME=EventHub

# Alternative
EMAILJS_SERVICE_ID=service_id
EMAILJS_TEMPLATE_ID=template_id
EMAILJS_USER_ID=user_id
```

## AI-Powered Chatbot

### Overview

Intelligent chatbot powered by Groq AI for answering user queries about events, bookings, and general FAQs.

### Features

1. **AI Integration**
   - Groq API for fast LLM inference
   - Context-aware responses
   - Event-specific information

2. **FAQ Support**
   - Pre-defined frequently asked questions
   - Instant responses
   - Knowledge base expansion

3. **User Interface**
   - Floating chat widget
   - Clean message interface
   - FAQ quick links
   - Real-time responses
   - Message history

### Chat Widget Component

**Location:** Bottom-right corner of page

**Features:**
- Minimize/maximize
- Message scrolling
- FAQ quick access
- Real-time typing indicators
- Timestamp on messages

**Props:**
```typescript
<ChatbotWidget
  eventId?: string // For context-aware responses
/>
```

### Sample Conversations

**User:** "When is the event?"
**Bot:** "The event is scheduled for July 15, 2024 at 6:00 PM at Grand Arena."

**User:** "How many seats are available?"
**Bot:** "Currently, 45 seats are available out of 200 total seats."

**User:** "What's the refund policy?"
**Bot:** "You can cancel your booking up to 24 hours before the event for a full refund. Refunds are processed within 5-7 business days."

### FAQ Database

```javascript
[
  {
    question: "How do I book tickets?",
    answer: "Browse events, select seats, fill in your details, and verify with OTP."
  },
  {
    question: "Can I cancel my booking?",
    answer: "Yes, you can cancel up to 24 hours before the event."
  },
  {
    question: "How will I receive my tickets?",
    answer: "Tickets are sent to your email immediately after booking."
  },
  ...
]
```

### Implementation

**Groq API Call:**
```javascript
const response = await axios.post(
  'https://api.groq.com/openai/v1/chat/completions',
  {
    model: 'mixtral-8x7b-32768',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage }
    ],
    max_tokens: 500,
    temperature: 0.7
  },
  { headers: { Authorization: `Bearer ${GROQ_API_KEY}` } }
)
```

**Backend Endpoint:**
```
POST /api/chat/message
{
  message: string,
  eventContext?: string // eventId for context
}

GET /api/chat/faq
```

### Configuration

**Backend (.env):**
```env
GROQ_API_KEY=your_groq_api_key
```

**Frontend (.env.local):**
```env
# Feature flag
NEXT_PUBLIC_ENABLE_CHATBOT=true
```

## Google Maps Integration

### Overview

Venue location display and navigation support using Google Maps API.

### Features

1. **Map Display**
   - Venue location marker
   - Address and coordinates
   - Interactive map (placeholder implementation)

2. **Navigation Options**
   - "Get Directions" - Opens Google Maps navigation
   - "View on Maps" - Standalone map view
   - "Search Location" - Google search results

3. **Venue Information**
   - Venue name and address
   - City, state, postal code
   - Coordinates (latitude, longitude)
   - Complete address display

### Venue Map Component

**Location:** Event details and booking pages

**Props:**
```typescript
<VenueMap
  venue={{
    name: string
    address: string
    city: string
    state: string
    postalCode: string
    latitude?: number
    longitude?: number
  }}
/>
```

### Implementation

**Backend Event Model:**
```javascript
venue: {
  name: String,
  address: String,
  city: String,
  state: String,
  postalCode: String,
  latitude: Number,
  longitude: Number
}
```

**Map Display Methods:**

1. Static Map Image API
2. Google Maps Embed API (requires upgrade)
3. Custom interactive map with Leaflet

### Navigation Links

```typescript
// Get Directions
https://www.google.com/maps/dir/?api=1&destination=
${encodeURIComponent(fullAddress)}

// View on Maps
https://maps.google.com/maps?q=${latitude},${longitude}

// Search Location
https://www.google.com/search?q=${encodeURIComponent(fullAddress)}
```

### Configuration

**Frontend (.env.local):**
```env
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_api_key
```

**Enable/Disable:**
```env
NEXT_PUBLIC_ENABLE_MAPS=true
```

## Real-time Updates

### Overview

Socket.IO-based real-time communication for live seat availability and booking updates.

### Features

1. **Live Seat Updates**
   - Instant seat status changes
   - Availability count updates
   - No page refresh needed

2. **Booking Notifications**
   - Booking confirmation to user
   - Multi-user booking coordination
   - Conflict prevention

3. **Event Rooms**
   - Users join event-specific rooms
   - Targeted updates
   - Efficient broadcasting

### Socket Events

**Client → Server:**
```javascript
// Join event
socket.emit('join-event', eventId)

// Leave event
socket.emit('leave-event', eventId)

// Join user room
socket.emit('join-user', userId)
```

**Server → Client:**
```javascript
// Seat update
socket.emit('seats-updated', {
  eventId: string,
  seats: Seat[],
  availableSeats: number,
  timestamp: Date
})

// Booking confirmation
socket.emit('booking-confirmed', {
  bookingId: string,
  confirmationCode: string,
  timestamp: Date
})

// Booking created (to other users)
socket.emit('booking-created', {
  eventId: string,
  availableSeats: number,
  totalBooked: number,
  timestamp: Date
})
```

### Implementation

**Backend (server.js):**
```javascript
import { Server as SocketIOServer } from 'socket.io'

const io = new SocketIOServer(httpServer, {
  cors: { origin: FRONTEND_URL }
})

io.on('connection', (socket) => {
  socket.on('join-event', (eventId) => {
    socket.join(`event-${eventId}`)
  })
})

// Broadcast updates
io.to(`event-${eventId}`).emit('seats-updated', data)
```

**Frontend (useEffect hook):**
```typescript
useEffect(() => {
  socketService.connect(token).then(() => {
    socketService.joinEvent(eventId)
    socketService.onSeatsUpdated(eventId, (data) => {
      // Update UI with new seat data
      setSeats(data.seats)
    })
  })

  return () => {
    socketService.leaveEvent(eventId)
  }
}, [eventId])
```

### Configuration

**Backend:**
```javascript
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
})
```

## Architecture Overview

### System Diagram

```
┌─────────────────────────────────────────┐
│         Frontend (Next.js)              │
├─────────────────────────────────────────┤
│ • React Components                      │
│ • API Client (axios)                    │
│ • Socket.IO Client                      │
│ • State Management (SWR, hooks)         │
└───────────────┬─────────────────────────┘
                │
         ┌──────┴──────┐
         │             │
    ┌────▼────┐  ┌────▼──────┐
    │   HTTP  │  │ WebSocket │
    │   REST  │  │ (Socket)  │
    └────┬────┘  └────┬──────┘
         │             │
    ┌────▼──────────────▼────┐
    │  Backend (Node.js)     │
    ├────────────────────────┤
    │ • Express Server       │
    │ • Socket.IO Server     │
    │ • Routes & Handlers    │
    │ • Services             │
    └────┬───────────┬───────┘
         │           │
    ┌────▼───┐  ┌───▼──────┐
    │ MongoDB│  │ Services │
    │        │  ├──────────┤
    │ Models:│  │• OTP     │
    │ • User │  │• Email   │
    │ • Event│  │• Chat    │
    │ • Book │  │• Payment │
    └────────┘  └──────────┘
         │
    ┌────▼─────────────────┐
    │  External Services   │
    ├──────────────────────┤
    │ • Groq AI (Chat)     │
    │ • Gmail SMTP (Email) │
    │ • Google Maps (Maps) │
    │ • MongoDB Atlas      │
    └──────────────────────┘
```

### Data Flow

1. **Booking Creation**
   ```
   User Form → OTP Verification → Backend Booking
   ↓
   Update Event Seats → Send Email Notification
   ↓
   Broadcast Real-time Update → Other Users See Updated Availability
   ```

2. **Chat Query**
   ```
   User Message → Backend Route → Groq API
   ↓
   AI Response → Send to Client → Display in Chat Widget
   ```

3. **Email Sending**
   ```
   Backend Event → Email Service → SMTP/EmailJS
   ↓
   Email Provider → User Inbox
   ```

## Summary of Advanced Features

| Feature | Technology | Status | User Impact |
|---------|-----------|--------|------------|
| OTP Verification | Node.js, Email | Implemented | Secure bookings |
| Email Notifications | Nodemailer, SMTP | Implemented | Instant confirmation |
| AI Chatbot | Groq API | Implemented | 24/7 support |
| Google Maps | Google Maps API | Implemented | Easy navigation |
| Real-time Updates | Socket.IO | Implemented | Live availability |

All features are production-ready and fully integrated with the main application.

## Next Steps

1. **Deployment**: Deploy backend to cloud (Heroku, AWS, etc.)
2. **Scaling**: Set up CDN for static assets, Redis for caching
3. **Monitoring**: Implement application monitoring and logging
4. **Analytics**: Add event tracking and user analytics
5. **Optimization**: Performance tuning and database indexing

---

For implementation details, refer to individual service documentation and API guides.
