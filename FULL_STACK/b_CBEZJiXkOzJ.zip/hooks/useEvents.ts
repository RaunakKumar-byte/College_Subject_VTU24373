'use client'

import { useState, useCallback, useEffect } from 'react'
import { Event, EventCategory } from '@/lib/types'

// Mock data - replace with API calls when Supabase is connected
const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Summer Music Festival 2024',
    category: 'Concert',
    description: 'Join us for an amazing night of live music featuring top artists from around the region.',
    startDate: new Date('2024-06-15T18:00:00'),
    endDate: new Date('2024-06-16T02:00:00'),
    duration: 480,
    location: 'Central Park Amphitheater',
    capacity: 500,
    totalSeats: 500,
    availableSeats: 120,
    ticketPrice: 1500,
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&h=300&fit=crop',
    organizerId: 'org-1',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '2',
    title: 'Web Development Workshop',
    category: 'Workshop',
    description: 'Learn modern web development techniques with hands-on exercises and real-world projects.',
    startDate: new Date('2024-06-22T10:00:00'),
    endDate: new Date('2024-06-22T14:00:00'),
    duration: 240,
    location: 'Tech Innovation Hub',
    capacity: 50,
    totalSeats: 50,
    availableSeats: 12,
    ticketPrice: 2500,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop',
    organizerId: 'org-1',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '3',
    title: 'Business Strategy Seminar',
    category: 'Seminar',
    description: 'Expert insights on building scalable businesses in the digital age.',
    startDate: new Date('2024-07-01T14:00:00'),
    endDate: new Date('2024-07-01T17:00:00'),
    duration: 180,
    location: 'Conference Center, Hall A',
    capacity: 200,
    totalSeats: 200,
    availableSeats: 85,
    ticketPrice: 1000,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop',
    organizerId: 'org-1',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

interface EventsFilter {
  category?: EventCategory | 'All'
  searchQuery?: string
  sortBy?: 'date' | 'price' | 'popularity'
}

export function useEvents() {
  const [events, setEvents] = useState<Event[]>([])
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load events (replace with API call when Supabase is connected)
  useEffect(() => {
    const loadEvents = async () => {
      try {
        setLoading(true)
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 500))
        setEvents(mockEvents)
        setFilteredEvents(mockEvents)
        setError(null)
      } catch (err) {
        setError('Failed to load events')
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    loadEvents()
  }, [])

  // Filter and search events
  const filterEvents = useCallback((filters: EventsFilter) => {
    let filtered = [...events]

    // Filter by category
    if (filters.category && filters.category !== 'All') {
      filtered = filtered.filter((event) => event.category === filters.category)
    }

    // Search by title or description
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase()
      filtered = filtered.filter(
        (event) =>
          event.title.toLowerCase().includes(query) ||
          event.description.toLowerCase().includes(query) ||
          event.location.toLowerCase().includes(query)
      )
    }

    // Sort events
    if (filters.sortBy === 'date') {
      filtered.sort((a, b) => a.startDate.getTime() - b.startDate.getTime())
    } else if (filters.sortBy === 'price') {
      filtered.sort((a, b) => a.ticketPrice - b.ticketPrice)
    }

    setFilteredEvents(filtered)
  }, [events])

  // Get single event by ID
  const getEventById = useCallback((id: string): Event | undefined => {
    return events.find((event) => event.id === id)
  }, [events])

  // Create event (for admin)
  const createEvent = useCallback(async (eventData: Omit<Event, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newEvent: Event = {
        ...eventData,
        id: `event-${Date.now()}`,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      setEvents([...events, newEvent])
      setFilteredEvents([...filteredEvents, newEvent])
      return newEvent
    } catch (err) {
      console.error('Failed to create event', err)
      throw err
    }
  }, [events, filteredEvents])

  // Update event (for admin)
  const updateEvent = useCallback(async (id: string, updates: Partial<Event>) => {
    try {
      const updated = events.map((event) =>
        event.id === id ? { ...event, ...updates, updatedAt: new Date() } : event
      )
      setEvents(updated)
      setFilteredEvents(updated)
    } catch (err) {
      console.error('Failed to update event', err)
      throw err
    }
  }, [events, filteredEvents])

  // Delete event (for admin)
  const deleteEvent = useCallback(async (id: string) => {
    try {
      const filtered = events.filter((event) => event.id !== id)
      setEvents(filtered)
      setFilteredEvents(filtered)
    } catch (err) {
      console.error('Failed to delete event', err)
      throw err
    }
  }, [events, filteredEvents])

  return {
    events: filteredEvents,
    allEvents: events,
    loading,
    error,
    filterEvents,
    getEventById,
    createEvent,
    updateEvent,
    deleteEvent,
  }
}
