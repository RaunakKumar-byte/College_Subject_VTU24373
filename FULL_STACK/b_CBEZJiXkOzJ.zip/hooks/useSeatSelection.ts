'use client'

import { useState, useCallback, useMemo } from 'react'
import { Seat } from '@/lib/types'
import { SEAT_LAYOUT } from '@/lib/constants'
import { generateSeats } from '@/lib/utils'

export function useSeatSelection(eventId: string, bookedSeats: string[] = []) {
  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [hoveredSeat, setHoveredSeat] = useState<string | null>(null)

  // Generate available seats for the event
  const availableSeats = useMemo(() => {
    const allSeats = generateSeats(SEAT_LAYOUT.ROWS, SEAT_LAYOUT.SEATS_PER_ROW)
    return allSeats.map((seat) => ({
      ...seat,
      isBooked: bookedSeats.includes(seat.seatNumber),
      bookingId: null,
      id: `${eventId}-${seat.seatNumber}`,
      eventId,
      createdAt: new Date(),
    })) as Seat[]
  }, [eventId, bookedSeats])

  // Toggle seat selection
  const toggleSeat = useCallback(
    (seatNumber: string) => {
      const seat = availableSeats.find((s) => s.seatNumber === seatNumber)

      // Can't select booked seats
      if (seat?.isBooked) {
        return false
      }

      setSelectedSeats((prev) => {
        if (prev.includes(seatNumber)) {
          return prev.filter((s) => s !== seatNumber)
        } else {
          return [...prev, seatNumber]
        }
      })
      return true
    },
    [availableSeats]
  )

  // Select multiple seats
  const selectMultipleSeats = useCallback(
    (seatNumbers: string[]) => {
      const validSeats = seatNumbers.filter((seatNumber) => {
        const seat = availableSeats.find((s) => s.seatNumber === seatNumber)
        return seat && !seat.isBooked && !selectedSeats.includes(seatNumber)
      })

      setSelectedSeats((prev) => [...prev, ...validSeats])
      return validSeats.length
    },
    [availableSeats, selectedSeats]
  )

  // Clear selection
  const clearSelection = useCallback(() => {
    setSelectedSeats([])
  }, [])

  // Get seat details
  const getSeatDetails = useCallback(
    (seatNumber: string) => {
      return availableSeats.find((s) => s.seatNumber === seatNumber)
    },
    [availableSeats]
  )

  // Get seats by row
  const getSeatsByRow = useCallback(
    (row: string) => {
      return availableSeats.filter((s) => s.row === row)
    },
    [availableSeats]
  )

  // Check if seat is selectable
  const isSeatSelectable = useCallback(
    (seatNumber: string) => {
      const seat = getSeatDetails(seatNumber)
      return seat && !seat.isBooked
    },
    [getSeatDetails]
  )

  // Get selection summary
  const getSelectionSummary = useMemo(
    () => ({
      totalSelected: selectedSeats.length,
      selectedSeats,
      isValid: selectedSeats.length > 0,
      unseatingNeeded: false,
    }),
    [selectedSeats]
  )

  return {
    selectedSeats,
    hoveredSeat,
    setHoveredSeat,
    availableSeats,
    toggleSeat,
    selectMultipleSeats,
    clearSelection,
    getSeatDetails,
    getSeatsByRow,
    isSeatSelectable,
    getSelectionSummary,
  }
}
