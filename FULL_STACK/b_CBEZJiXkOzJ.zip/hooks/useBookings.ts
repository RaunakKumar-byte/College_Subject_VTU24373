'use client'

import { useState, useCallback } from 'react'
import { Booking } from '@/lib/types'
import { generateTicketNumber, generateConfirmationCode } from '@/lib/utils'
import { NotificationService } from '@/lib/email-service'

// Mock bookings storage
let mockBookings: Booking[] = []

export function useBookings() {
  const [bookings, setBookings] = useState<Booking[]>(mockBookings)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Get user bookings
  const getUserBookings = useCallback((userId: string) => {
    return bookings.filter((booking) => booking.userId === userId)
  }, [bookings])

  // Get event bookings (admin)
  const getEventBookings = useCallback((eventId: string) => {
    return bookings.filter((booking) => booking.eventId === eventId)
  }, [bookings])

  // Get booking by ID
  const getBookingById = useCallback((bookingId: string) => {
    return bookings.find((booking) => booking.id === bookingId)
  }, [bookings])

  // Create booking
  const createBooking = useCallback(
    async (bookingData: Omit<Booking, 'id' | 'ticketNumber' | 'confirmationCode' | 'bookingDate'>) => {
      try {
        setLoading(true)
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 500))

        const newBooking: Booking = {
          ...bookingData,
          id: `booking-${Date.now()}`,
          ticketNumber: generateTicketNumber(),
          confirmationCode: generateConfirmationCode(),
          bookingDate: new Date(),
        }

        setBookings([...bookings, newBooking])
        mockBookings = [...mockBookings, newBooking]
        setError(null)
        return newBooking
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to create booking'
        setError(errorMessage)
        throw err
      } finally {
        setLoading(false)
      }
    },
    [bookings]
  )

  // Update booking status
  const updateBookingStatus = useCallback(
    async (bookingId: string, status: 'Pending' | 'Confirmed' | 'Cancelled') => {
      try {
        setLoading(true)
        await new Promise((resolve) => setTimeout(resolve, 300))

        const updated = bookings.map((booking) =>
          booking.id === bookingId ? { ...booking, status } : booking
        )
        setBookings(updated)
        mockBookings = updated
        setError(null)
      } catch (err) {
        setError('Failed to update booking')
        throw err
      } finally {
        setLoading(false)
      }
    },
    [bookings]
  )

  // Cancel booking
  const cancelBooking = useCallback(
    async (bookingId: string) => {
      return updateBookingStatus(bookingId, 'Cancelled')
    },
    [updateBookingStatus]
  )

  // Get booking statistics
  const getBookingStats = useCallback((eventId: string) => {
    const eventBookings = bookings.filter(
      (booking) => booking.eventId === eventId && booking.status === 'Confirmed'
    )
    const totalBookings = eventBookings.length
    const totalRevenue = eventBookings.reduce((sum, booking) => sum + booking.totalPrice, 0)
    const totalSeatsBooked = eventBookings.reduce((sum, booking) => sum + booking.quantity, 0)

    return {
      totalBookings,
      totalRevenue,
      totalSeatsBooked,
    }
  }, [bookings])

  return {
    bookings,
    loading,
    error,
    getUserBookings,
    getEventBookings,
    getBookingById,
    createBooking,
    updateBookingStatus,
    cancelBooking,
    getBookingStats,
  }
}
