import jwt from 'jsonwebtoken'
import User from '../models/User.js'

// Protect routes - require authentication
export const protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No authorization token provided',
      })
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    const user = await User.findById(decoded.id)

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User not found',
      })
    }

    req.user = user
    next()
  } catch (error) {
    res.status(401).json({
      success: false,
      message: 'Invalid or expired token',
    })
  }
}

// Admin only routes
export const adminOnly = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access required',
    })
  }
  next()
}

// Rate limiting middleware
import rateLimit from 'express-rate-limit'

export const otpLimiter = rateLimit({
  windowMs: 60000, // 1 minute
  max: 3, // 3 requests per minute
  message: 'Too many OTP requests, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
})

export const bookingLimiter = rateLimit({
  windowMs: 60000, // 1 minute
  max: 5, // 5 bookings per minute
  message: 'Too many booking requests, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
})

export const generalLimiter = rateLimit({
  windowMs: 900000, // 15 minutes
  max: 100,
  message: 'Too many requests from this IP',
  standardHeaders: true,
  legacyHeaders: false,
})
