// Generate confirmation code
export const generateConfirmationCode = () => {
  return Math.random().toString(36).substring(2, 10).toUpperCase()
}

// Generate ticket number
export const generateTicketNumber = () => {
  return `TKT-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`
}

// Generate OTP
export const generateOTP = (length = 6) => {
  return Math.floor(Math.pow(10, length - 1) + Math.random() * (Math.pow(10, length) - Math.pow(10, length - 1)))
    .toString()
    .padStart(length, '0')
}

// Generate seat layout
export const generateSeats = (rows, seatsPerRow) => {
  const seats = []
  for (const row of rows) {
    for (let col = 1; col <= seatsPerRow; col++) {
      seats.push({
        seatNumber: `${row}${col}`,
        row,
        column: col,
        status: 'available',
        bookedBy: null,
      })
    }
  }
  return seats
}
