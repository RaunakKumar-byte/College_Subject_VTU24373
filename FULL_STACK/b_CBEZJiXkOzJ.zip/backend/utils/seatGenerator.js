// Generate seat layout for an event
export const generateSeats = (rows, seatsPerRow) => {
  const seats = []
  for (const row of rows) {
    for (let col = 1; col <= seatsPerRow; col++) {
      seats.push({
        seatNumber: `${row}${col}`,
        row,
        column: col,
        status: 'available',
        bookedBy: null,
      })
    }
  }
  return seats
}

// Get seat layout information
export const getSeatLayoutInfo = (totalSeats) => {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
  const seatsPerRow = Math.ceil(totalSeats / rows.length)
  
  return {
    rows: rows.slice(0, Math.ceil(totalSeats / seatsPerRow)),
    seatsPerRow,
  }
}

// Generate seat grid for UI
export const generateSeatGrid = (seats) => {
  const grid = {}
  
  seats.forEach(seat => {
    if (!grid[seat.row]) {
      grid[seat.row] = []
    }
    grid[seat.row][seat.column - 1] = seat
  })
  
  return grid
}

// Get occupied and available seat counts
export const getSeatStats = (seats) => {
  const available = seats.filter(s => s.status === 'available').length
  const booked = seats.filter(s => s.status === 'booked').length
  const reserved = seats.filter(s => s.status === 'reserved').length
  
  return {
    total: seats.length,
    available,
    booked,
    reserved,
    occupancyRate: ((booked / seats.length) * 100).toFixed(2),
  }
}
