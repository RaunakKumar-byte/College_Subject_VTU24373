import nodemailer from 'nodemailer'
import axios from 'axios'

// Initialize Nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
})

// Email templates
const emailTemplates = {
  otpTemplate: (name, otp) => ({
    subject: 'Your EventHub OTP Code',
    html: `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <h2>Welcome to EventHub, ${name}!</h2>
          <p>Your One-Time Password (OTP) is:</p>
          <h1 style="color: #007bff; letter-spacing: 5px;">${otp}</h1>
          <p>This code will expire in 5 minutes.</p>
          <p>If you didn't request this code, please ignore this email.</p>
          <hr/>
          <p style="font-size: 12px; color: #666;">
            EventHub &copy; ${new Date().getFullYear()}
          </p>
        </body>
      </html>
    `,
  }),

  bookingConfirmationTemplate: (booking, event, user) => ({
    subject: `Booking Confirmed - ${event.title}`,
    html: `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <h2>Booking Confirmed!</h2>
          <p>Hello ${user.firstName},</p>
          
          <h3>Event Details</h3>
          <p>
            <strong>Event:</strong> ${event.title}<br/>
            <strong>Date:</strong> ${new Date(event.eventDate).toLocaleDateString()}<br/>
            <strong>Time:</strong> ${event.eventTime}<br/>
            <strong>Venue:</strong> ${event.venue.name}, ${event.venue.city}
          </p>
          
          <h3>Booking Information</h3>
          <p>
            <strong>Confirmation Code:</strong> ${booking.confirmationCode}<br/>
            <strong>Number of Tickets:</strong> ${booking.numberOfTickets}<br/>
            <strong>Total Amount:</strong> Rs. ${booking.totalAmount}
          </p>
          
          <h3>Tickets</h3>
          <p>Your ticket numbers: ${booking.ticketNumbers.join(', ')}</p>
          
          <p style="margin-top: 20px;">
            Please keep this confirmation email safe. You'll need the confirmation code at the venue.
          </p>
          
          <hr/>
          <p style="font-size: 12px; color: #666;">
            If you have any questions, please contact us at support@eventhub.com
          </p>
        </body>
      </html>
    `,
  }),

  bookingReminderTemplate: (event, user) => ({
    subject: `Reminder: ${event.title} is coming soon!`,
    html: `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <h2>Event Reminder</h2>
          <p>Hello ${user.firstName},</p>
          
          <p>This is a friendly reminder about your upcoming event:</p>
          
          <h3>${event.title}</h3>
          <p>
            <strong>Date:</strong> ${new Date(event.eventDate).toLocaleDateString()}<br/>
            <strong>Time:</strong> ${event.eventTime}<br/>
            <strong>Venue:</strong> ${event.venue.name}, ${event.venue.city}
          </p>
          
          <p>We look forward to seeing you there!</p>
          
          <hr/>
          <p style="font-size: 12px; color: #666;">
            EventHub &copy; ${new Date().getFullYear()}
          </p>
        </body>
      </html>
    `,
  }),

  cancellationTemplate: (booking, event, user) => ({
    subject: `Booking Cancelled - ${event.title}`,
    html: `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <h2>Booking Cancelled</h2>
          <p>Hello ${user.firstName},</p>
          
          <p>Your booking has been cancelled.</p>
          
          <h3>Event Details</h3>
          <p>
            <strong>Event:</strong> ${event.title}<br/>
            <strong>Confirmation Code:</strong> ${booking.confirmationCode}<br/>
            <strong>Refund Amount:</strong> Rs. ${booking.totalAmount}
          </p>
          
          <p>The refund will be processed within 5-7 business days.</p>
          
          <hr/>
          <p style="font-size: 12px; color: #666;">
            If you have any questions, please contact us at support@eventhub.com
          </p>
        </body>
      </html>
    `,
  }),
}

// Send email using Nodemailer
export const sendEmail = async (to, template) => {
  try {
    const mailOptions = {
      from: `${process.env.FROM_NAME} <${process.env.FROM_EMAIL}>`,
      to,
      ...template,
    }

    const info = await transporter.sendMail(mailOptions)
    console.log('Email sent:', info.response)
    return { success: true, messageId: info.messageId }
  } catch (error) {
    console.error('Email sending error:', error)
    throw new Error(`Failed to send email: ${error.message}`)
  }
}

// Send OTP via email
export const sendEmailOTP = async (email, otp, name = 'User') => {
  const template = emailTemplates.otpTemplate(name, otp)
  return await sendEmail(email, template)
}

// Send booking confirmation email
export const sendBookingConfirmation = async (user, booking, event) => {
  const template = emailTemplates.bookingConfirmationTemplate(booking, event, user)
  return await sendEmail(user.email, template)
}

// Send booking reminder email
export const sendBookingReminder = async (user, event) => {
  const template = emailTemplates.bookingReminderTemplate(event, user)
  return await sendEmail(user.email, template)
}

// Send cancellation email
export const sendCancellationEmail = async (user, booking, event) => {
  const template = emailTemplates.cancellationTemplate(booking, event, user)
  return await sendEmail(user.email, template)
}

// Send email using EmailJS API (Alternative)
export const sendEmailViaEmailJS = async (to, subject, html) => {
  try {
    if (!process.env.EMAILJS_USER_ID) {
      console.warn('EmailJS not configured, falling back to Nodemailer')
      return
    }

    const response = await axios.post('https://api.emailjs.com/api/v1.0/email/send', {
      service_id: process.env.EMAILJS_SERVICE_ID,
      template_id: process.env.EMAILJS_TEMPLATE_ID,
      user_id: process.env.EMAILJS_USER_ID,
      template_params: {
        to_email: to,
        subject: subject,
        html: html,
      },
    })

    return { success: true, data: response.data }
  } catch (error) {
    console.error('EmailJS error:', error)
    throw new Error(`Failed to send email via EmailJS: ${error.message}`)
  }
}

// Mock SMS sending function
export const sendSmsOTP = async (phone, otp) => {
  try {
    // In production, integrate with SMS gateway like Twilio, AWS SNS, etc.
    // For now, just log
    console.log(`[SMS] OTP to ${phone}: ${otp}`)
    return { success: true, message: 'SMS sent' }
  } catch (error) {
    throw new Error(`Failed to send SMS: ${error.message}`)
  }
}
