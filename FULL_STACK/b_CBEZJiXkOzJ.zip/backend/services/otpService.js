import OTP from '../models/OTP.js'
import { sendEmailOTP, sendSmsOTP } from './emailService.js'

const OTP_EXPIRY = process.env.OTP_EXPIRY_TIME || 300000 // 5 minutes
const OTP_LENGTH = parseInt(process.env.OTP_LENGTH) || 6

// Generate random OTP
export const generateOTP = () => {
  return Math.floor(Math.pow(10, OTP_LENGTH - 1) + Math.random() * (Math.pow(10, OTP_LENGTH) - Math.pow(10, OTP_LENGTH - 1)))
    .toString()
    .padStart(OTP_LENGTH, '0')
}

// Send OTP to user
export const sendOTP = async (userId, user, method = 'email', purpose = 'booking') => {
  try {
    const code = generateOTP()
    const expiresAt = new Date(Date.now() + OTP_EXPIRY)
    const destination = method === 'email' ? user.email : user.phone

    // Delete any existing OTP for this user and method
    await OTP.deleteMany({ user: userId, method })

    // Create new OTP
    const otpDoc = new OTP({
      user: userId,
      code,
      method,
      destination,
      purpose,
      expiresAt,
    })

    await otpDoc.save()

    // Send OTP
    if (method === 'email') {
      await sendEmailOTP(user.email, code, user.firstName)
    } else if (method === 'phone') {
      // For demo purposes, log to console. In production, use SMS gateway
      console.log(`SMS OTP for ${user.phone}: ${code}`)
      // await sendSmsOTP(user.phone, code)
    }

    return {
      success: true,
      message: `OTP sent to ${method}`,
      method,
      destination: method === 'email' ? user.email : user.phone.slice(-4),
    }
  } catch (error) {
    throw new Error(`Failed to send OTP: ${error.message}`)
  }
}

// Verify OTP
export const verifyOTP = async (userId, code, method, purpose = 'booking') => {
  try {
    const otpDoc = await OTP.findOne({
      user: userId,
      code,
      method,
      purpose,
      expiresAt: { $gt: new Date() },
    })

    if (!otpDoc) {
      throw new Error('Invalid or expired OTP')
    }

    // Check attempts
    if (otpDoc.attempts >= otpDoc.maxAttempts) {
      await OTP.deleteOne({ _id: otpDoc._id })
      throw new Error('Maximum OTP attempts exceeded')
    }

    // Mark as verified
    otpDoc.isVerified = true
    await otpDoc.save()

    return {
      success: true,
      message: 'OTP verified successfully',
      otpId: otpDoc._id,
    }
  } catch (error) {
    // Increment attempts
    await OTP.findOneAndUpdate(
      { user: userId, code, method, purpose },
      { $inc: { attempts: 1 } }
    )
    throw new Error(error.message)
  }
}

// Check if OTP is verified
export const checkOTPVerification = async (userId, purpose = 'booking') => {
  const otpDoc = await OTP.findOne({
    user: userId,
    purpose,
    isVerified: true,
    expiresAt: { $gt: new Date() },
  })

  return !!otpDoc
}

// Resend OTP
export const resendOTP = async (userId, user, method = 'email', purpose = 'booking') => {
  try {
    // Check if user has already requested OTP recently
    const recentOTP = await OTP.findOne({
      user: userId,
      method,
      purpose,
      createdAt: { $gt: new Date(Date.now() - 60000) }, // Within last minute
    })

    if (recentOTP) {
      throw new Error('Please wait before requesting another OTP')
    }

    return await sendOTP(userId, user, method, purpose)
  } catch (error) {
    throw new Error(error.message)
  }
}
