import mongoose from 'mongoose'

const otpSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  code: {
    type: String,
    required: true,
  },
  method: {
    type: String,
    enum: ['email', 'phone'],
    required: true,
  },
  destination: {
    type: String,
    required: true, // email or phone number
  },
  attempts: {
    type: Number,
    default: 0,
  },
  maxAttempts: {
    type: Number,
    default: 3,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  purpose: {
    type: String,
    enum: ['booking', 'verification', 'password_reset'],
    default: 'booking',
  },
  relatedBooking: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    default: null,
  },
  expiresAt: {
    type: Date,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

// TTL index to automatically delete expired OTPs
otpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 })

export default mongoose.model('OTP', otpSchema)
