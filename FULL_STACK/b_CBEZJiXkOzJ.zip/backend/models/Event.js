import mongoose from 'mongoose'

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Event title is required'],
    trim: true,
  },
  description: {
    type: String,
    required: [true, 'Event description is required'],
  },
  category: {
    type: String,
    enum: ['concert', 'workshop', 'seminar', 'sports', 'conference', 'other'],
    required: true,
  },
  eventDate: {
    type: Date,
    required: [true, 'Event date is required'],
  },
  eventTime: {
    type: String,
    required: true,
  },
  venue: {
    name: String,
    address: String,
    city: String,
    state: String,
    postalCode: String,
    latitude: Number,
    longitude: Number,
  },
  totalSeats: {
    type: Number,
    required: [true, 'Total seats is required'],
    min: 1,
  },
  availableSeats: {
    type: Number,
    required: true,
  },
  ticketPrice: {
    type: Number,
    required: [true, 'Ticket price is required'],
    min: 0,
  },
  organizerEmail: {
    type: String,
    required: true,
  },
  image: String,
  tags: [String],
  seats: [{
    seatNumber: String,
    row: String,
    column: Number,
    status: {
      type: String,
      enum: ['available', 'booked', 'reserved'],
      default: 'available',
    },
    bookedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  }],
  bookings: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
  }],
  isActive: {
    type: Boolean,
    default: true,
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
}, { timestamps: true })

// Index for faster queries
eventSchema.index({ eventDate: 1, category: 1 })
eventSchema.index({ city: 1 })

export default mongoose.model('Event', eventSchema)
