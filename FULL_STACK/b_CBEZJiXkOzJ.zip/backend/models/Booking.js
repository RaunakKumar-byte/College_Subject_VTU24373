import mongoose from 'mongoose'

const bookingSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  event: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Event',
    required: true,
  },
  seats: [{
    seatNumber: String,
    price: Number,
  }],
  totalAmount: {
    type: Number,
    required: true,
  },
  numberOfTickets: {
    type: Number,
    required: true,
    min: 1,
  },
  bookingStatus: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled'],
    default: 'pending',
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending',
  },
  transactionId: String,
  confirmationCode: {
    type: String,
    unique: true,
  },
  ticketNumbers: [String],
  customerName: String,
  customerEmail: String,
  customerPhone: String,
  specialRequests: String,
  otpVerified: {
    type: Boolean,
    default: false,
  },
  otpMethod: {
    type: String,
    enum: ['email', 'phone'],
  },
  notificationSent: {
    type: Boolean,
    default: false,
  },
  notificationDetails: {
    emailSent: Boolean,
    smsSent: Boolean,
    emailTimestamp: Date,
    smsTimestamp: Date,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
}, { timestamps: true })

// Index for faster queries
bookingSchema.index({ user: 1, createdAt: -1 })
bookingSchema.index({ event: 1 })
bookingSchema.index({ confirmationCode: 1 })

export default mongoose.model('Booking', bookingSchema)
