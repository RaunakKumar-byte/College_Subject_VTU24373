# EventHub Backend Server

A Node.js and Express-based backend server for the EventHub ticket booking application with MongoDB integration, real-time updates using Socket.IO, OTP verification, email notifications, and AI-powered chatbot support.

## Table of Contents

1. [Installation](#installation)
2. [Configuration](#configuration)
3. [Running the Server](#running-the-server)
4. [API Endpoints](#api-endpoints)
5. [Database Models](#database-models)
6. [Features](#features)
7. [Real-time Updates](#real-time-updates)

## Installation

### Prerequisites

- Node.js (v14 or higher)
- MongoDB (local or cloud instance)
- npm or pnpm

### Steps

1. Install dependencies:

```bash
pnpm install
# or
npm install
```

2. Create a `.env` file based on `.env.example`:

```bash
cp .env.example .env
```

3. Configure environment variables (see Configuration section).

## Configuration

Update the `.env` file with your configuration:

```env
# Server
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:3000

# Database
MONGODB_URI=mongodb://localhost:27017/eventhub
MONGODB_USERNAME=admin
MONGODB_PASSWORD=password

# JWT
JWT_SECRET=your_secret_key_here
JWT_EXPIRE=7d

# Email (Gmail example)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
FROM_EMAIL=noreply@eventhub.com
FROM_NAME=EventHub

# OTP Configuration
OTP_EXPIRY_TIME=300000 # 5 minutes
OTP_LENGTH=6
MAX_OTP_ATTEMPTS=3

# Groq AI
GROQ_API_KEY=your_groq_api_key

# Google Maps
GOOGLE_MAPS_API_KEY=your_google_maps_key

# Rate Limiting
RATE_LIMIT_WINDOW=900000 # 15 minutes
RATE_LIMIT_MAX_REQUESTS=100
```

### Setting up Email (Gmail)

1. Enable 2-factor authentication on your Gmail account
2. Generate an app password at https://myaccount.google.com/apppasswords
3. Use the app password in the `SMTP_PASSWORD` field

### Setting up Groq AI

1. Sign up at https://console.groq.com
2. Create an API key
3. Add it to your `.env` file

## Running the Server

### Development Mode

```bash
pnpm dev
# or
npm run dev
```

The server will start with nodemon for automatic restarts on file changes.

### Production Mode

```bash
pnpm start
# or
npm start
```

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/profile` - Update user profile

### Events

- `GET /api/events` - Get all events (with filtering)
- `GET /api/events/:id` - Get event details
- `POST /api/events` - Create event (admin only)
- `PUT /api/events/:id` - Update event (admin only)
- `DELETE /api/events/:id` - Delete event (admin only)
- `GET /api/events/:id/seats` - Get seat details

### Bookings

- `POST /api/bookings` - Create booking
- `GET /api/bookings` - Get user bookings
- `GET /api/bookings/:id` - Get booking details
- `PUT /api/bookings/:id/cancel` - Cancel booking

### OTP

- `POST /api/otp/send` - Send OTP via email/phone
- `POST /api/otp/verify` - Verify OTP code
- `POST /api/otp/resend` - Resend OTP

### Email

- `POST /api/email/send-confirmation` - Send booking confirmation
- `POST /api/email/send-reminder` - Send event reminder
- `POST /api/email/send-cancellation` - Send cancellation email

### Chat

- `POST /api/chat/message` - Send message to chatbot
- `GET /api/chat/faq` - Get FAQ list

### User

- `GET /api/user/profile` - Get user profile
- `GET /api/user/bookings` - Get booking history
- `GET /api/user/stats` - Get booking statistics
- `PUT /api/user/otp-preference` - Update OTP preference

## Database Models

### User

```typescript
{
  firstName: String
  lastName: String
  email: String (unique)
  phone: String (unique)
  password: String (hashed)
  role: 'user' | 'admin'
  isEmailVerified: Boolean
  isPhoneVerified: Boolean
  preferredOtpMethod: 'email' | 'phone'
  bookings: [Booking]
  createdAt: Date
  updatedAt: Date
}
```

### Event

```typescript
{
  title: String
  description: String
  category: String
  eventDate: Date
  eventTime: String
  venue: {
    name: String
    address: String
    city: String
    state: String
    postalCode: String
    latitude: Number
    longitude: Number
  }
  totalSeats: Number
  availableSeats: Number
  ticketPrice: Number
  seats: [Seat]
  bookings: [Booking]
  createdBy: User
  createdAt: Date
}
```

### Booking

```typescript
{
  user: User
  event: Event
  seats: [{seatNumber, price}]
  totalAmount: Number
  numberOfTickets: Number
  bookingStatus: 'pending' | 'confirmed' | 'cancelled'
  paymentStatus: 'pending' | 'completed' | 'failed' | 'refunded'
  confirmationCode: String
  ticketNumbers: [String]
  otpVerified: Boolean
  otpMethod: 'email' | 'phone'
  notificationSent: Boolean
  createdAt: Date
}
```

### OTP

```typescript
{
  user: User
  code: String
  method: 'email' | 'phone'
  destination: String
  isVerified: Boolean
  purpose: 'booking' | 'verification' | 'password_reset'
  attempts: Number
  expiresAt: Date
}
```

## Features

### 1. Authentication
- User registration and login
- JWT token-based authentication
- Password hashing with bcrypt
- Role-based access control (user, admin)

### 2. Event Management
- Create, read, update, delete events
- Seat management and availability tracking
- Event filtering by category, location, date

### 3. Booking System
- Create and manage bookings
- Seat selection and reservation
- Booking status tracking
- Cancellation with refund support

### 4. OTP Verification
- Two methods: Email and SMS
- 5-minute expiration
- Rate limiting (3 requests per minute)
- Automatic cleanup of expired OTPs

### 5. Email Notifications
- Booking confirmations
- Event reminders
- Cancellation notices
- Nodemailer and EmailJS integration

### 6. AI Chatbot
- Groq AI integration for intelligent responses
- FAQ support
- Event context-aware answers
- Rate limiting

### 7. Real-time Updates
- Socket.IO for live seat updates
- Booking status notifications
- Connected client tracking

## Real-time Updates

The backend uses Socket.IO to provide real-time updates for:

1. **Seat Updates** - When a seat is booked/released
2. **Booking Confirmations** - When a booking is completed
3. **Event Updates** - When event details change

### Client-side Integration

```typescript
import { socketService } from '@/lib/socket-service'

// Connect
await socketService.connect(token)

// Join event room
socketService.joinEvent(eventId)

// Listen for updates
socketService.onSeatsUpdated(eventId, (data) => {
  console.log('Seats updated:', data)
})

// Cleanup
socketService.leaveEvent(eventId)
```

## Error Handling

The server includes comprehensive error handling:

- Input validation with proper error messages
- Rate limiting to prevent abuse
- JWT token expiration handling
- Database connection error handling
- Email sending failure handling

## Security

- CORS configuration for frontend
- Helmet.js for HTTP headers security
- Rate limiting on sensitive endpoints
- Input validation and sanitization
- Password hashing with bcrypt
- JWT token authentication

## Monitoring

Check server health at: `GET /api/health`

Response:
```json
{
  "status": "Server is running",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

## Troubleshooting

1. **MongoDB Connection Error**
   - Check if MongoDB is running
   - Verify MONGODB_URI in .env
   - Check username and password

2. **Email Not Sending**
   - Verify SMTP credentials
   - Check Gmail app password if using Gmail
   - Check spam folder

3. **OTP Issues**
   - Verify OTP_EXPIRY_TIME setting
   - Check rate limiting configuration
   - Ensure email service is working

4. **Socket.IO Connection Issues**
   - Verify CORS configuration
   - Check client URL matches FRONTEND_URL
   - Ensure Socket.IO is properly initialized

## Support

For issues or questions, please create an issue on the project repository.
