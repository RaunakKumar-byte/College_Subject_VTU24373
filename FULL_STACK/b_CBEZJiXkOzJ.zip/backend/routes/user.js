import express from 'express'
import { protect } from '../middleware/auth.js'
import User from '../models/User.js'
import Booking from '../models/Booking.js'

const router = express.Router()

// Get user profile
router.get('/profile', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password')

    res.json({
      success: true,
      user,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get user booking history
router.get('/bookings', protect, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate('event', 'title eventDate venue category')
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      count: bookings.length,
      bookings,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get booking statistics
router.get('/stats', protect, async (req, res) => {
  try {
    const totalBookings = await Booking.countDocuments({ user: req.user._id })
    const upcomingBookings = await Booking.countDocuments({
      user: req.user._id,
      'event.eventDate': { $gt: new Date() },
    })

    const bookings = await Booking.find({ user: req.user._id }).populate('event')

    const totalSpent = bookings.reduce((sum, booking) => sum + booking.totalAmount, 0)

    res.json({
      success: true,
      stats: {
        totalBookings,
        upcomingBookings,
        totalSpent,
      },
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Update OTP preference
router.put('/otp-preference', protect, async (req, res) => {
  try {
    const { method } = req.body

    if (!['email', 'phone'].includes(method)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP method',
      })
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { preferredOtpMethod: method },
      { new: true }
    )

    res.json({
      success: true,
      message: 'OTP preference updated',
      user: user.toJSON(),
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
