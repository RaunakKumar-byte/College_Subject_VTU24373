import express from 'express'
import { protect, otpLimiter } from '../middleware/auth.js'
import { sendOTP, verifyOTP, resendOTP } from '../services/otpService.js'

const router = express.Router()

// Send OTP
router.post('/send', protect, otpLimiter, async (req, res) => {
  try {
    const { method = 'email', purpose = 'booking' } = req.body

    if (!['email', 'phone'].includes(method)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP method. Use email or phone',
      })
    }

    const result = await sendOTP(req.user._id, req.user, method, purpose)

    res.json({
      success: true,
      message: result.message,
      data: result,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Verify OTP
router.post('/verify', protect, async (req, res) => {
  try {
    const { code, method, purpose = 'booking' } = req.body

    if (!code || !method) {
      return res.status(400).json({
        success: false,
        message: 'OTP code and method are required',
      })
    }

    const result = await verifyOTP(req.user._id, code, method, purpose)

    res.json({
      success: true,
      message: result.message,
      data: result,
    })
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    })
  }
})

// Resend OTP
router.post('/resend', protect, otpLimiter, async (req, res) => {
  try {
    const { method = 'email', purpose = 'booking' } = req.body

    const result = await resendOTP(req.user._id, req.user, method, purpose)

    res.json({
      success: true,
      message: result.message,
      data: result,
    })
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
