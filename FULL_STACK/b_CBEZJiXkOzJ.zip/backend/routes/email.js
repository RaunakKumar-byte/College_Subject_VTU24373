import express from 'express'
import { protect, generalLimiter } from '../middleware/auth.js'
import {
  sendBookingConfirmation,
  sendBookingReminder,
  sendCancellationEmail,
} from '../services/emailService.js'
import Booking from '../models/Booking.js'
import Event from '../models/Event.js'

const router = express.Router()

// Send booking confirmation email
router.post('/send-confirmation', protect, async (req, res) => {
  try {
    const { bookingId } = req.body

    const booking = await Booking.findById(bookingId).populate('event user')

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      })
    }

    if (booking.user._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
      })
    }

    await sendBookingConfirmation(req.user, booking, booking.event)

    // Update notification status
    booking.notificationSent = true
    booking.notificationDetails = {
      ...booking.notificationDetails,
      emailSent: true,
      emailTimestamp: new Date(),
    }
    await booking.save()

    res.json({
      success: true,
      message: 'Confirmation email sent successfully',
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Send event reminder email
router.post('/send-reminder', protect, async (req, res) => {
  try {
    const { eventId } = req.body

    const event = await Event.findById(eventId)

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    await sendBookingReminder(req.user, event)

    res.json({
      success: true,
      message: 'Reminder email sent successfully',
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Send cancellation email
router.post('/send-cancellation', protect, async (req, res) => {
  try {
    const { bookingId } = req.body

    const booking = await Booking.findById(bookingId).populate('event')

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      })
    }

    if (booking.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
      })
    }

    await sendCancellationEmail(req.user, booking, booking.event)

    res.json({
      success: true,
      message: 'Cancellation email sent successfully',
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
