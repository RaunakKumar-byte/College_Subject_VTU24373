import express from 'express'
import { protect, bookingLimiter } from '../middleware/auth.js'
import Booking from '../models/Booking.js'
import Event from '../models/Event.js'
import { generateConfirmationCode, generateTicketNumber } from '../utils/generators.js'
import { sendBookingConfirmation } from '../services/emailService.js'

const router = express.Router()

// Create booking
router.post('/', protect, bookingLimiter, async (req, res) => {
  try {
    const {
      eventId,
      seats,
      customerName,
      customerEmail,
      customerPhone,
      specialRequests = '',
      otpVerified = false,
      otpMethod = 'email',
    } = req.body

    // Validation
    if (!eventId || !seats || seats.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Event and seats are required',
      })
    }

    if (!customerName || !customerEmail || !customerPhone) {
      return res.status(400).json({
        success: false,
        message: 'Customer details are required',
      })
    }

    // Get event
    const event = await Event.findById(eventId)

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    // Check seat availability
    const selectedSeats = event.seats.filter(seat => seats.includes(seat.seatNumber))

    if (selectedSeats.length !== seats.length) {
      return res.status(400).json({
        success: false,
        message: 'Some selected seats are not available',
      })
    }

    const unavailableSeats = selectedSeats.filter(seat => seat.status !== 'available')
    if (unavailableSeats.length > 0) {
      return res.status(400).json({
        success: false,
        message: `Seats ${unavailableSeats.map(s => s.seatNumber).join(', ')} are not available`,
      })
    }

    // Generate ticket numbers
    const ticketNumbers = seats.map(() => generateTicketNumber())

    // Calculate total amount
    const totalAmount = seats.length * event.ticketPrice

    // Create booking
    const booking = new Booking({
      user: req.user._id,
      event: eventId,
      seats: selectedSeats.map(seat => ({
        seatNumber: seat.seatNumber,
        price: event.ticketPrice,
      })),
      totalAmount,
      numberOfTickets: seats.length,
      customerName,
      customerEmail,
      customerPhone,
      specialRequests,
      confirmationCode: generateConfirmationCode(),
      ticketNumbers,
      otpVerified,
      otpMethod,
    })

    await booking.save()

    // Update event seats
    event.seats = event.seats.map(seat => {
      if (seats.includes(seat.seatNumber)) {
        return {
          ...seat,
          status: 'booked',
          bookedBy: req.user._id,
        }
      }
      return seat
    })

    event.availableSeats -= seats.length
    event.bookings.push(booking._id)
    await event.save()

    // Update user bookings
    req.user.bookings.push(booking._id)
    await req.user.save()

    // Send confirmation email
    try {
      await sendBookingConfirmation(req.user, booking, event)
      booking.notificationSent = true
      booking.notificationDetails = {
        emailSent: true,
        emailTimestamp: new Date(),
      }
      await booking.save()
    } catch (emailError) {
      console.error('Email sending failed:', emailError)
      // Don't fail the booking if email fails
    }

    // Emit real-time update via Socket.IO
    const io = req.app.get('io')
    io.to(`event-${eventId}`).emit('booking-created', {
      eventId,
      availableSeats: event.availableSeats,
      totalBooked: event.totalSeats - event.availableSeats,
      timestamp: new Date(),
    })

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      booking,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get user bookings
router.get('/', protect, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate('event', 'title eventDate venue ticketPrice')
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      count: bookings.length,
      bookings,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get single booking
router.get('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('event user')

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      })
    }

    if (booking.user._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
      })
    }

    res.json({
      success: true,
      booking,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Cancel booking
router.put('/:id/cancel', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found',
      })
    }

    if (booking.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized',
      })
    }

    // Check if booking can be cancelled
    const event = await Event.findById(booking.event)
    const hoursUntilEvent = (new Date(event.eventDate) - new Date()) / (1000 * 60 * 60)

    if (hoursUntilEvent < 24) {
      return res.status(400).json({
        success: false,
        message: 'Cannot cancel booking within 24 hours of event',
      })
    }

    // Update booking status
    booking.bookingStatus = 'cancelled'
    booking.paymentStatus = 'refunded'
    await booking.save()

    // Free up seats
    event.seats = event.seats.map(seat => {
      if (booking.seats.some(bs => bs.seatNumber === seat.seatNumber)) {
        return {
          ...seat,
          status: 'available',
          bookedBy: null,
        }
      }
      return seat
    })

    event.availableSeats += booking.numberOfTickets
    await event.save()

    res.json({
      success: true,
      message: 'Booking cancelled successfully',
      booking,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
