import express from 'express'
import { protect, adminOnly } from '../middleware/auth.js'
import Event from '../models/Event.js'
import { generateSeats } from '../utils/seatGenerator.js'

const router = express.Router()

// Get all events with filters
router.get('/', async (req, res) => {
  try {
    const { category, city, search, date, sortBy = 'eventDate' } = req.query

    let filter = { isActive: true }

    if (category) filter.category = category
    if (city) filter['venue.city'] = city
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ]
    }
    if (date) {
      const startDate = new Date(date)
      const endDate = new Date(date)
      endDate.setDate(endDate.getDate() + 1)
      filter.eventDate = { $gte: startDate, $lt: endDate }
    }

    const events = await Event.find(filter)
      .select('-seats')
      .sort(sortBy === 'price' ? { ticketPrice: 1 } : { eventDate: 1 })
      .limit(50)

    res.json({
      success: true,
      count: events.length,
      events,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get single event with seat details
router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    res.json({
      success: true,
      event,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Create event (admin only)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      eventDate,
      eventTime,
      venue,
      totalSeats,
      ticketPrice,
      tags = [],
      image,
    } = req.body

    // Validation
    if (!title || !description || !category || !eventDate || !totalSeats || ticketPrice === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields',
      })
    }

    // Generate seats
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
    const seatsPerRow = Math.ceil(totalSeats / rows.length)
    const seats = generateSeats(rows, seatsPerRow).slice(0, totalSeats)

    const event = new Event({
      title,
      description,
      category,
      eventDate,
      eventTime,
      venue,
      totalSeats,
      availableSeats: totalSeats,
      ticketPrice,
      organizerEmail: req.user.email,
      tags,
      image,
      seats,
      createdBy: req.user._id,
    })

    await event.save()

    res.status(201).json({
      success: true,
      message: 'Event created successfully',
      event,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Update event (admin only)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const allowedFields = [
      'title',
      'description',
      'eventDate',
      'eventTime',
      'venue',
      'ticketPrice',
      'tags',
      'image',
      'isActive',
    ]

    const updates = {}
    Object.keys(req.body).forEach(key => {
      if (allowedFields.includes(key)) {
        updates[key] = req.body[key]
      }
    })

    const event = await Event.findByIdAndUpdate(req.params.id, updates, { new: true })

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    res.json({
      success: true,
      message: 'Event updated successfully',
      event,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Delete event (admin only)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    const event = await Event.findByIdAndDelete(req.params.id)

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    res.json({
      success: true,
      message: 'Event deleted successfully',
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

// Get available seats for an event
router.get('/:id/seats', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).select('seats availableSeats')

    if (!event) {
      return res.status(404).json({
        success: false,
        message: 'Event not found',
      })
    }

    const availableSeats = event.seats.filter(seat => seat.status === 'available')

    res.json({
      success: true,
      totalSeats: event.seats.length,
      availableCount: event.availableSeats,
      seats: event.seats,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
