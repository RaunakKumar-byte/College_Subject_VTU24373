import express from 'express'
import axios from 'axios'
import { protect, generalLimiter } from '../middleware/auth.js'
import Event from '../models/Event.js'

const router = express.Router()

// Get chat response from Groq AI
router.post('/message', generalLimiter, async (req, res) => {
  try {
    const { message, eventContext = null } = req.body

    if (!message || message.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Message cannot be empty',
      })
    }

    // Get event context if provided
    let contextData = ''
    if (eventContext) {
      const event = await Event.findById(eventContext).select(
        'title description eventDate eventTime venue ticketPrice totalSeats availableSeats'
      )
      if (event) {
        contextData = `
Current Event Information:
- Title: ${event.title}
- Description: ${event.description}
- Date: ${new Date(event.eventDate).toLocaleDateString()}
- Time: ${event.eventTime}
- Venue: ${event.venue.name}, ${event.venue.city}
- Ticket Price: Rs. ${event.ticketPrice}
- Available Seats: ${event.availableSeats}/${event.totalSeats}
`
      }
    }

    // Prepare prompt for Groq AI
    const systemPrompt = `You are a helpful EventHub customer support chatbot. You help users with questions about events, bookings, tickets, and venue information. Be friendly, concise, and provide accurate information. If you don't know something, suggest contacting support@eventhub.com.
${contextData ? `Context: ${contextData}` : ''}`

    // Call Groq API
    const response = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model: 'mixtral-8x7b-32768',
        messages: [
          {
            role: 'system',
            content: systemPrompt,
          },
          {
            role: 'user',
            content: message,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    )

    const botMessage = response.data.choices[0].message.content

    res.json({
      success: true,
      message: botMessage,
      timestamp: new Date(),
    })
  } catch (error) {
    console.error('Chat error:', error.response?.data || error.message)
    res.status(500).json({
      success: false,
      message: 'Failed to get response from chatbot. Please try again later.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined,
    })
  }
})

// Get FAQ responses
router.get('/faq', async (req, res) => {
  try {
    const faqs = [
      {
        question: 'How do I book tickets?',
        answer:
          'Browse events, select your preferred event, choose seats, fill in your details, and proceed to checkout. You\'ll receive a confirmation with your ticket numbers.',
      },
      {
        question: 'Can I cancel my booking?',
        answer:
          'Yes, you can cancel bookings up to 24 hours before the event. Refunds will be processed within 5-7 business days.',
      },
      {
        question: 'How will I receive my tickets?',
        answer:
          'Your tickets will be sent to your registered email address immediately after booking confirmation. You can also view them in your account dashboard.',
      },
      {
        question: 'What is the refund policy?',
        answer:
          'Refunds are processed within 5-7 business days for cancellations made 24 hours before the event.',
      },
      {
        question: 'Can I transfer my tickets to someone else?',
        answer:
          'Tickets are non-transferable and must be used by the person whose name is on the ticket.',
      },
      {
        question: 'How do I contact support?',
        answer:
          'You can reach our support team at support@eventhub.com or through the chat widget available on our website.',
      },
      {
        question: 'What payment methods do you accept?',
        answer:
          'We accept credit cards, debit cards, and digital wallets for secure payment processing.',
      },
      {
        question: 'Is there an age restriction for events?',
        answer:
          'Age restrictions vary by event. Please check the event details for specific age requirements.',
      },
    ]

    res.json({
      success: true,
      faqs,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    })
  }
})

export default router
