import express from 'express'
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import cors from 'cors'
import helmet from 'helmet'
import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'

// Load environment variables
dotenv.config()

// Import routes
import authRoutes from './routes/auth.js'
import eventRoutes from './routes/events.js'
import bookingRoutes from './routes/bookings.js'
import otpRoutes from './routes/otp.js'
import emailRoutes from './routes/email.js'
import chatRoutes from './routes/chat.js'
import userRoutes from './routes/user.js'

const app = express()
const httpServer = createServer(app)
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
})

// Middleware
app.use(helmet())
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ limit: '10mb', extended: true }))

// Make io accessible to routes
app.set('io', io)

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/eventhub')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err))

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/events', eventRoutes)
app.use('/api/bookings', bookingRoutes)
app.use('/api/otp', otpRoutes)
app.use('/api/email', emailRoutes)
app.use('/api/chat', chatRoutes)
app.use('/api/user', userRoutes)

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server is running', timestamp: new Date() })
})

// Socket.IO Real-time Updates
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id)

  // Event listeners for real-time updates
  socket.on('join-event', (eventId) => {
    socket.join(`event-${eventId}`)
  })

  socket.on('leave-event', (eventId) => {
    socket.leave(`event-${eventId}`)
  })

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id)
  })
})

// Broadcast seat updates to all connected clients
export const broadcastSeatUpdate = (eventId, updatedSeats) => {
  io.to(`event-${eventId}`).emit('seats-updated', {
    eventId,
    seats: updatedSeats,
    timestamp: new Date(),
  })
}

// Broadcast booking confirmation
export const broadcastBookingConfirmation = (userId, bookingData) => {
  io.to(`user-${userId}`).emit('booking-confirmed', bookingData)
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err)
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
  })
})

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' })
})

const PORT = process.env.PORT || 5000
httpServer.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`)
})
