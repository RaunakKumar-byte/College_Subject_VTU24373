# EventHub Advanced Features - Quick Reference

## Everything You Need to Know in 5 Minutes

### What's New?

Five powerful advanced features have been added to EventHub:

1. **OTP Verification** - Secure bookings with 6-digit codes
2. **Email Notifications** - Automatic confirmations and reminders
3. **AI Chatbot** - 24/7 customer support
4. **Google Maps** - Venue location & navigation
5. **Real-time Updates** - Live seat availability

### Quick Start

```bash
# Terminal 1: Backend
cd backend
pnpm install
cp .env.example .env
# Edit .env with your credentials
pnpm dev

# Terminal 2: Frontend
pnpm install
cp .env.example .env.local
# Edit .env.local with your API URL
pnpm dev
```

Visit: http://localhost:3000

### Feature Overview

#### 1. OTP Verification
- When: During booking confirmation
- How: User receives 6-digit code via Email or SMS
- Process: Enter code → Verify → Complete booking
- Security: 5-minute expiry, max 3 attempts

#### 2. Email Notifications
- Booking Confirmation (immediate)
- Event Reminder (24 hours before)
- Cancellation Notice (with refund info)

**Setup:** Update `.env` with SMTP credentials
```env
SMTP_HOST=smtp.gmail.com
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=app_password
```

#### 3. AI Chatbot
- Location: Bottom-right corner
- Ask: Anything about events
- Examples:
  - "How much are tickets?"
  - "When is the event?"
  - "What's the refund policy?"

**Setup:** Add Groq API key
```env
GROQ_API_KEY=your_key
```

#### 4. Google Maps
- Where: Event detail & booking pages
- Shows: Venue location & address
- Links: Get Directions, View on Maps

#### 5. Real-time Seat Updates
- Automatic: No refresh needed
- Live: See availability as others book
- Smart: Prevents double-booking

### Configuration Files

**Backend (.env):**
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/eventhub
JWT_SECRET=your_secret
SMTP_HOST=smtp.gmail.com
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
GROQ_API_KEY=your_groq_key
```

**Frontend (.env.local):**
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_SOCKET_URL=http://localhost:5000
```

### File Locations

**Backend Routes:**
- `/api/auth/` - Authentication
- `/api/otp/` - OTP operations
- `/api/email/` - Notifications
- `/api/chat/` - Chatbot
- `/api/events/` - Event management
- `/api/bookings/` - Booking system

**Frontend Components:**
- `components/booking/otp-verification.tsx` - OTP modal
- `components/chat/chatbot-widget.tsx` - Chat widget
- `components/events/venue-map.tsx` - Map display

### Testing

Quick test for each feature:

1. **OTP**: Complete a booking → Verify with code
2. **Email**: Check inbox for confirmation
3. **Chatbot**: Click chat → Ask "What's the price?"
4. **Maps**: View any event → See venue location
5. **Real-time**: Open event on 2 tabs → Book on tab 1 → See update on tab 2

### Common Issues

| Issue | Solution |
|-------|----------|
| "Cannot connect to backend" | Check backend running on port 5000 |
| "Email not received" | Check SMTP credentials in .env |
| "OTP error" | Verify Groq API key is set |
| "Real-time not working" | Check Socket.IO connection |

### API Quick Reference

```bash
# Register user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName":"John","lastName":"Doe",
    "email":"john@example.com","phone":"9876543210",
    "password":"test123","passwordConfirm":"test123"
  }'

# Send OTP
curl -X POST http://localhost:5000/api/otp/send \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"method":"email","purpose":"booking"}'

# Verify OTP
curl -X POST http://localhost:5000/api/otp/verify \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"code":"123456","method":"email"}'

# Create booking
curl -X POST http://localhost:5000/api/bookings \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "eventId":"event_id",
    "seats":["A1","A2"],
    "customerName":"John Doe",
    "customerEmail":"john@example.com",
    "customerPhone":"9876543210",
    "otpVerified":true
  }'

# Get events
curl -X GET http://localhost:5000/api/events
```

### Database Setup

**MongoDB Locally:**
```bash
# Install MongoDB
# Run it
mongod

# Create database
mongosh
> use eventhub
> db.createUser({user:"admin",pwd:"password",roles:["readWrite"]})
```

**MongoDB Cloud (Atlas):**
1. Sign up: https://www.mongodb.com/cloud/atlas
2. Create cluster
3. Get connection string
4. Add to `.env`: `MONGODB_URI=mongodb+srv://...`

### Security Checklist

- [ ] Changed JWT_SECRET to strong value
- [ ] Set SMTP credentials correctly
- [ ] Added Groq API key
- [ ] CORS enabled for frontend URL
- [ ] Database user created with password
- [ ] Rate limiting configured
- [ ] Input validation enabled

### Production Deployment

**Backend (Heroku):**
```bash
heroku create eventhub-backend
git push heroku main
heroku config:set MONGODB_URI=your_cloud_uri
heroku config:set JWT_SECRET=strong_secret
```

**Frontend (Vercel):**
```bash
vercel deploy
# Set env vars in dashboard
```

### Performance Tips

1. Enable database indexing
2. Use Redis for caching
3. Compress responses
4. Use CDN for assets
5. Monitor API response times

### Feature Enablement

Control features via environment variables:

```env
NEXT_PUBLIC_ENABLE_OTP=true
NEXT_PUBLIC_ENABLE_CHATBOT=true
NEXT_PUBLIC_ENABLE_MAPS=true
NEXT_PUBLIC_ENABLE_NOTIFICATIONS=true
```

### Documentation Map

| Document | Purpose | Size |
|----------|---------|------|
| BACKEND_INTEGRATION.md | Setup guide | 474 lines |
| TESTING_GUIDE.md | Test cases | 501 lines |
| FEATURES.md | Feature details | 664 lines |
| ADVANCED_FEATURES_SUMMARY.md | Complete overview | 538 lines |
| backend/README.md | Backend docs | 375 lines |

### Key Endpoints

**Authentication:**
- `POST /api/auth/register` - New account
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Current user

**Events:**
- `GET /api/events` - List events
- `GET /api/events/:id` - Event details
- `GET /api/events/:id/seats` - Seat info

**Bookings:**
- `POST /api/bookings` - Create booking
- `GET /api/bookings` - My bookings
- `PUT /api/bookings/:id/cancel` - Cancel

**Advanced:**
- `POST /api/otp/send` - Send OTP
- `POST /api/otp/verify` - Verify OTP
- `POST /api/chat/message` - Chat with bot
- `GET /api/chat/faq` - FAQ list

### Support Resources

1. **Getting Started**: BACKEND_INTEGRATION.md
2. **Testing**: TESTING_GUIDE.md
3. **Technical Details**: FEATURES.md
4. **Backend Setup**: backend/README.md
5. **Complete Overview**: ADVANCED_FEATURES_SUMMARY.md

### Next Steps

1. ✓ Setup MongoDB
2. ✓ Configure email service
3. ✓ Add Groq API key
4. ✓ Set up Google Maps
5. ✓ Run backend & frontend
6. ✓ Test all features
7. ✓ Deploy to production

### Code Statistics

- Backend: ~2,000 lines
- Frontend: ~900 lines
- Documentation: ~2,600 lines
- Total: ~5,500 lines

### Technology Summary

```
Frontend: Next.js + React + Tailwind CSS
Backend: Node.js + Express + MongoDB
Real-time: Socket.IO
AI: Groq API
Email: Nodemailer/EmailJS
Maps: Google Maps API
```

### Common Commands

```bash
# Development
pnpm dev              # Run app
pnpm build           # Build for prod
pnpm start           # Start production

# Backend
cd backend && pnpm dev    # Run backend
cd backend && pnpm build  # Build backend

# Testing
npm test             # Run tests
npm run lint        # Check code quality

# Database
mongosh             # Connect to MongoDB
```

### Troubleshooting Quick Guide

**Backend won't start:**
```bash
# Check port not in use
lsof -i :5000

# Check MongoDB connection
mongosh
> show dbs
```

**Frontend can't reach backend:**
```bash
# Check .env.local has correct API URL
cat .env.local

# Test API
curl http://localhost:5000/api/health
```

**Email not sending:**
```bash
# Verify credentials in .env
# Check spam folder
# Review server logs
```

**Chatbot not working:**
```bash
# Verify GROQ_API_KEY in .env
# Check API key hasn't expired
# Review backend logs
```

### Quick Links

- Frontend: http://localhost:3000
- Backend: http://localhost:5000
- API Health: http://localhost:5000/api/health
- MongoDB: mongodb://localhost:27017/eventhub

### Important Notes

⚠️ **Before Production:**
- [ ] Change all default passwords
- [ ] Enable HTTPS
- [ ] Setup monitoring
- [ ] Configure backups
- [ ] Test with real data
- [ ] Security audit
- [ ] Performance testing

### Feature Highlights

- 🔐 Dual-method OTP verification
- 📧 Automated email notifications
- 💬 AI-powered 24/7 chatbot
- 🗺️ Google Maps integration
- ⚡ Real-time seat updates
- 🔑 JWT authentication
- 🛡️ Rate limiting & security
- 📱 Fully responsive design

---

**Ready to go live?** Check ADVANCED_FEATURES_SUMMARY.md for deployment instructions.

**Questions?** Refer to the documentation files or check the inline code comments.

**Happy booking!** 🎫
