# EventHub - Departmental Event Ticket Booking System

## Overview
EventHub is a comprehensive event ticketing platform designed for departmental events. It provides seamless ticket booking, seat selection, and management capabilities for both administrators and users.

## Features

### For Users
- Browse and search events by category, date, and location
- Interactive seat selection with real-time availability
- Secure ticket booking with multiple payment methods
- Ticket management and cancellation
- Email notifications for confirmations and reminders
- Receipt downloads and QR code tickets

### For Admins
- Complete event management (create, edit, delete events)
- Real-time seat availability tracking
- Revenue analytics and occupancy rates
- Booking statistics and reports
- Email notification templates
- Admin dashboard with overview metrics

## Tech Stack

- **Framework**: Next.js 16 with TypeScript
- **UI Components**: shadcn/ui (built on Radix UI)
- **Styling**: Tailwind CSS
- **Form Management**: React Hook Form + Zod validation
- **Charts**: Recharts
- **Date Handling**: date-fns
- **Notifications**: Sonner toast notifications
- **Email Service**: Ready for Resend or SendGrid integration

## Project Structure

```
app/
├── admin/              # Admin dashboard
│   └── page.tsx       # Admin panel with event management
├── booking/           # Booking flow
│   ├── [eventId]/     # Event-specific booking page
│   └── confirmation/  # Booking confirmation page
├── events/            # Event browsing
│   └── page.tsx       # Browse and filter events
├── tickets/           # User ticket management
│   └── page.tsx       # View and manage bookings
├── user/              # User dashboard
│   └── page.tsx       # User profile and bookings
├── layout.tsx         # Root layout
└── page.tsx           # Landing page

components/
├── admin/
│   ├── event-form.tsx        # Event creation/editing form
│   ├── event-list.tsx        # Events list for admin
│   └── analytics-dashboard.tsx # Analytics charts
├── booking/
│   ├── seat-selector.tsx      # Interactive seat selection
│   └── booking-form.tsx       # Booking form
└── shared/
    ├── header.tsx            # Navigation header
    └── event-card.tsx        # Event display card

lib/
├── types.ts           # TypeScript interfaces
├── constants.ts       # App constants and categories
├── validation.ts      # Zod validation schemas
├── utils.ts           # Helper functions
└── email-service.ts   # Email notification templates

hooks/
├── useEvents.ts       # Events management hook
├── useBookings.ts     # Bookings management hook
└── useSeatSelection.ts # Seat selection logic
```

## Getting Started

### Prerequisites
- Node.js 18+
- pnpm (recommended) or npm

### Installation

1. Install dependencies:
```bash
pnpm install
```

2. Start the development server:
```bash
pnpm dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser

## Key Routes

- `/` - Landing page
- `/events` - Browse events
- `/booking/[eventId]` - Book tickets for an event
- `/booking/confirmation/[bookingId]` - View booking confirmation
- `/tickets` - My tickets
- `/user` - User dashboard
- `/admin` - Admin dashboard

## Data Models

### Event
- ID, title, category, description
- Start/end dates, duration, location
- Capacity, available seats, ticket price
- Event image URL

### Booking
- ID, event ID, user ID
- Attendee information (name, email, phone)
- Selected seats, quantity, total price
- Payment method, booking status
- Ticket number, confirmation code

### Seat
- ID, event ID, seat number
- Row and column information
- Booking status (available/booked)

## Integration Points

### Email Notifications
The email service is structured and ready for integration with:
- **Resend** (recommended)
- **SendGrid**
- **AWS SES**
- **Any email service provider**

Email templates are pre-built for:
- Booking confirmations
- Booking cancellations
- Event reminders (24 hours before)

To connect an email service:
1. Set up your email provider account
2. Add API key to environment variables
3. Uncomment the email service code in `lib/email-service.ts`

### Database Integration
The application is structured for easy integration with:
- **Supabase** (recommended) - SQL database with auth
- **Neon** - PostgreSQL serverless
- **Firebase** - NoSQL alternative

Current state: Mock data stored in memory

To add database:
1. Connect your database provider
2. Create tables based on the types in `lib/types.ts`
3. Replace mock data calls with real API calls in hooks

## Features Ready for Enhancement

### Completed
- Event browsing and filtering
- Interactive seat selection
- Booking form with validation
- Admin event management
- Analytics dashboard
- Email notification structure

### Ready for Integration
- Email service (Resend, SendGrid, etc.)
- Database persistence (Supabase, Neon, etc.)
- User authentication (Auth.js, Supabase Auth)
- Payment processing (Stripe, Razorpay)
- PDF ticket generation
- QR code generation

### Future Enhancements
- User accounts and authentication
- Payment gateway integration
- Refund management
- Event analytics by organizer
- Bulk ticket sales
- Waitlist management
- Event recommendation engine

## Development Guidelines

### Adding a New Feature

1. **Update Types** - Add new interfaces to `lib/types.ts`
2. **Add Validation** - Create Zod schemas in `lib/validation.ts`
3. **Update Constants** - Add new constants if needed
4. **Create Components** - Build UI components in `components/`
5. **Create Hooks** - Add data management logic if needed
6. **Add Routes** - Create new pages in `app/`
7. **Test** - Use the preview to verify functionality

### Code Style

- Use TypeScript for type safety
- Follow the existing component structure
- Use shadcn/ui components for consistency
- Implement form validation with Zod
- Add error handling with try-catch
- Use toast notifications for user feedback

## Environment Variables

Currently, the application doesn't require environment variables. When integrating services, add:

```
# Email Service
RESEND_API_KEY=your_resend_api_key
# or
SENDGRID_API_KEY=your_sendgrid_api_key

# Database
DATABASE_URL=your_database_url

# Authentication
NEXTAUTH_SECRET=your_secret
NEXTAUTH_URL=http://localhost:3000

# Payments
STRIPE_PUBLIC_KEY=your_stripe_public_key
STRIPE_SECRET_KEY=your_stripe_secret_key
```

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

### Docker

```bash
docker build -t eventhub .
docker run -p 3000:3000 eventhub
```

### Other Platforms

The application is built with Next.js and can be deployed to any platform that supports Node.js:
- Netlify
- AWS Amplify
- Railway
- Render
- Heroku

## Testing

Current setup uses mock data. To test:

1. **Landing Page** - `/`
2. **Browse Events** - `/events`
3. **Book Tickets** - Select an event and go through booking flow
4. **Admin Dashboard** - `/admin` to create/edit events
5. **Bookings** - `/tickets` to view your bookings
6. **User Dashboard** - `/user` to see bookings and discover events

Mock data includes:
- 3 sample events
- Pre-configured seat layouts
- Mock bookings for testing

## Performance Optimizations

- Image optimization with Next.js Image component
- Component code splitting
- Efficient re-renders with useCallback
- Form validation on client side
- Responsive design for all devices

## Accessibility

- Semantic HTML elements
- ARIA labels on interactive elements
- Keyboard navigation support
- Color contrast compliance
- Focus states for form elements

## Support & Contribution

For issues, feature requests, or contributions, please refer to the project documentation and coding guidelines above.

## License

This project is licensed under the MIT License.

---

**Last Updated**: May 2024
**Version**: 1.0.0
