# EventHub - Quick Start Guide

## 🚀 Getting Started in 30 Seconds

### 1. Install Dependencies
```bash
pnpm install
```

### 2. Run Development Server
```bash
pnpm dev
```

### 3. Open in Browser
Go to [http://localhost:3000](http://localhost:3000)

## 📍 Key Routes to Explore

| Route | Description |
|-------|-------------|
| `/` | Landing page |
| `/events` | Browse and search events |
| `/admin` | Admin dashboard (create events, analytics) |
| `/booking/[eventId]` | Book tickets for an event |
| `/tickets` | View your bookings |
| `/user` | User dashboard with bookings & discovery |

## 🎯 Testing the App

### Try as a User
1. Go to `/events`
2. Click "Book Now" on any event
3. Select seats and provide attendee info
4. Complete the booking
5. View your confirmation at `/tickets`

### Try as an Admin
1. Go to `/admin`
2. Click "Create Event" button
3. Fill in event details
4. View analytics and event management

## 📦 What's Included

### Pages Built
- ✅ Landing page with features overview
- ✅ Event browsing with filters
- ✅ Interactive seat selection
- ✅ Multi-step booking form
- ✅ Booking confirmation
- ✅ Ticket management
- ✅ User dashboard
- ✅ Admin dashboard with analytics

### Features Ready
- ✅ Event management (create, edit, delete)
- ✅ Seat selection with availability
- ✅ Form validation
- ✅ Booking history
- ✅ Analytics & reporting
- ✅ Responsive design
- ✅ Toast notifications
- ✅ Email templates (ready for integration)

## 🔌 Next Steps for Production

### Phase 1: Authentication (Week 1)
```
1. Connect Supabase Auth
2. Update header.tsx with real auth
3. Protect admin routes
```

### Phase 2: Database (Week 2)
```
1. Connect Neon/Supabase database
2. Replace mock data in hooks
3. Add real data persistence
```

### Phase 3: Email (Week 3)
```
1. Sign up for Resend
2. Add API key to env vars
3. Uncomment email code in lib/email-service.ts
```

### Phase 4: Payments (Week 4)
```
1. Integrate Stripe/Razorpay
2. Update booking flow
3. Add payment confirmation
```

## 📝 Sample Event Data

The app comes with 3 mock events:
1. **Summer Music Festival** - Concert
2. **Web Development Workshop** - Workshop  
3. **Business Strategy Seminar** - Seminar

All have pre-configured seats and bookable tickets.

## 🎨 Customization

### Colors & Theme
Edit `app/globals.css` to change colors

### Event Categories
Edit `lib/constants.ts` EVENT_CATEGORIES

### Validation Rules
Edit `lib/validation.ts` schemas

### Seat Layout
Edit `SEAT_LAYOUT` in `lib/constants.ts`

## 📚 Documentation

- **SETUP.md** - Complete setup & integration guide
- **PROJECT_SUMMARY.md** - Full feature list & architecture

## 🐛 Troubleshooting

### Dev Server Won't Start
```bash
rm -rf .next node_modules pnpm-lock.yaml
pnpm install
pnpm dev
```

### Module Not Found
```bash
pnpm add [package-name]
```

### Type Errors
```bash
pnpm build
# Check error messages for types to fix
```

## 💡 Pro Tips

1. **Search Events** - Use the search bar to filter by name/location
2. **Admin Analytics** - Check `/admin` for real-time stats
3. **Seat Selection** - Hover over seats to preview, click to select
4. **Keyboard Nav** - Use Tab to navigate forms
5. **Mobile View** - Works great on phones and tablets

## 🔑 Important Files

| File | Purpose |
|------|---------|
| `lib/types.ts` | All TypeScript interfaces |
| `lib/validation.ts` | Form validation schemas |
| `hooks/useEvents.ts` | Event management logic |
| `hooks/useBookings.ts` | Booking management logic |
| `components/booking/seat-selector.tsx` | Seat selection UI |

## 📞 Need Help?

1. Check `SETUP.md` for detailed info
2. Review component comments
3. Check TypeScript types for data structures
4. Review hooks for business logic

## 🎉 You're Ready!

The app is fully functional. Start by exploring the different pages and testing the booking flow. Then integrate with your backend services when ready.

Happy building! 🚀
