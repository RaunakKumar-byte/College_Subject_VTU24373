# EventHub Testing Guide

Comprehensive guide for testing all features of the EventHub ticket booking application.

## Table of Contents

1. [Setup for Testing](#setup-for-testing)
2. [Feature Testing](#feature-testing)
3. [API Testing](#api-testing)
4. [Real-time Testing](#real-time-testing)
5. [Troubleshooting](#troubleshooting)

## Setup for Testing

### Prerequisites

- Backend server running on `http://localhost:5000`
- Frontend app running on `http://localhost:3000`
- MongoDB running with test data
- Groq API key configured
- Email service configured

### Create Test User

Use the registration form at `/auth/register` or:

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@example.com",
    "phone": "9876543210",
    "password": "test123",
    "passwordConfirm": "test123"
  }'
```

## Feature Testing

### 1. Authentication

#### Test Case 1.1: User Registration

1. Navigate to http://localhost:3000/auth/register
2. Fill in form:
   - First Name: Test
   - Last Name: User
   - Email: test@example.com
   - Phone: 9876543210
   - Password: Test@123
3. Click Register
4. **Expected**: Redirected to dashboard, token stored in localStorage

#### Test Case 1.2: User Login

1. Navigate to http://localhost:3000/auth/login
2. Enter credentials:
   - Email: test@example.com
   - Password: Test@123
3. Click Login
4. **Expected**: Logged in successfully, token stored

#### Test Case 1.3: Invalid Login

1. Enter wrong password
2. **Expected**: Error message "Invalid email or password"

### 2. Event Browsing

#### Test Case 2.1: View Events

1. Navigate to http://localhost:3000/events
2. **Expected**: See list of events with details
3. Filter by category: Select "Concert"
4. **Expected**: Only concert events displayed
5. Filter by city: Select "Delhi"
6. **Expected**: Only Delhi events displayed

#### Test Case 2.2: Event Details

1. Click on any event
2. **Expected**: Detailed view with:
   - Event title, description
   - Date, time, venue
   - Available seats count
   - Ticket price
   - Venue map

### 3. Booking System

#### Test Case 3.1: Seat Selection

1. Open event booking page
2. Click on 3 different seats
3. **Expected**: Seats highlighted in blue, seat numbers displayed
4. Click on a booked seat
5. **Expected**: Cannot select (disabled or grayed out)

#### Test Case 3.2: Booking Form

1. Select seats
2. Scroll to booking form
3. Fill in attendee details:
   - Name: John Doe
   - Email: john@example.com
   - Phone: 9876543210
4. Select OTP method: Email
5. Click "Proceed to Payment"
6. **Expected**: OTP modal appears

### 4. OTP Verification

#### Test Case 4.1: Send OTP via Email

1. In OTP modal, select "Email"
2. Click "Send OTP"
3. **Expected**: Message "OTP sent to your email"
4. Check email inbox for OTP
5. **Note**: For testing without email setup, check server console logs

#### Test Case 4.2: Verify OTP

1. Copy OTP from email/console
2. Enter in modal input (6 digits)
3. Click "Verify OTP"
4. **Expected**: "OTP verified successfully!" message
5. **Expected**: Booking is confirmed

#### Test Case 4.3: Invalid OTP

1. Enter wrong OTP code
2. Click Verify
3. **Expected**: Error "Invalid OTP"
4. Try 3 times
5. **Expected**: After 3 attempts, error "Maximum OTP attempts exceeded"

#### Test Case 4.4: Resend OTP

1. Click "Resend OTP"
2. **Expected**: New OTP sent
3. Should not allow immediate resend
4. **Expected**: "Please wait before requesting another OTP"

### 5. Email Notifications

#### Test Case 5.1: Booking Confirmation Email

1. Complete a booking
2. Check email for confirmation
3. **Expected**: Email contains:
   - Event title, date, time
   - Booking confirmation code
   - Ticket numbers
   - Total amount

#### Test Case 5.2: Event Reminder Email

1. User with upcoming booking
2. Admin or system sends reminder
3. **Expected**: Email sent 24 hours before event

#### Test Case 5.3: Cancellation Email

1. Cancel a booking
2. **Expected**: Cancellation email received
3. Email should contain refund information

### 6. Chatbot

#### Test Case 6.1: Open Chatbot

1. Look for chat button in bottom-right corner
2. Click to open chat widget
3. **Expected**: Chat window opens with greeting

#### Test Case 6.2: Ask Question

1. Type: "What is the ticket price?"
2. Click Send or press Enter
3. **Expected**: Bot responds with answer
4. Type another question: "When does the event start?"
5. **Expected**: Relevant response about event timing

#### Test Case 6.3: View FAQs

1. Click "View FAQs" button
2. **Expected**: Common FAQs displayed
3. Click on FAQ answer
4. **Expected**: Answer displayed in chat

#### Test Case 6.4: Event-Specific Context

1. From event page, open chatbot
2. Ask: "How many seats are available?"
3. **Expected**: Bot provides event-specific information

### 7. Google Maps

#### Test Case 7.1: View Venue Map

1. Open event details/booking page
2. Scroll to "Event Venue" section
3. **Expected**: Map shows venue location
4. Venue details displayed (name, address, coordinates)

#### Test Case 7.2: Get Directions

1. Click "Get Directions on Google Maps"
2. **Expected**: Opens Google Maps in new tab
3. Shows route from current location to venue

#### Test Case 7.3: Alternative Map Views

1. Click "View on Maps"
2. **Expected**: Opens standalone map
3. Click "Search Location"
4. **Expected**: Google search results for venue

### 8. User Dashboard

#### Test Case 8.1: View Bookings

1. Navigate to /user or My Bookings
2. **Expected**: List of all user bookings
3. Show booking details: confirmation code, status, date

#### Test Case 8.2: Download Ticket

1. From booking list, click a booking
2. **Expected**: Booking details with QR code
3. Option to download/print ticket

#### Test Case 8.3: Cancel Booking

1. Click "Cancel Booking"
2. **Expected**: Confirmation dialog
3. Confirm cancellation
4. **Expected**: Booking status changed to "Cancelled"
5. **Expected**: Cancellation email sent

### 9. Real-time Updates

#### Test Case 9.1: Seat Availability

1. Open same event on two browser windows
2. In window 1, book 5 seats
3. In window 2, check seat availability
4. **Expected**: Seats updated in real-time (within seconds)

#### Test Case 9.2: Multiple Users

1. Have two users book different seats simultaneously
2. **Expected**: Both bookings succeed without conflicts
3. Seat inventory updated correctly

## API Testing

### Using cURL or Postman

#### Register User

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "phone": "9876543210",
    "password": "password123",
    "passwordConfirm": "password123"
  }'
```

#### Login

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
```

Response includes token. Use for subsequent requests:

```bash
TOKEN="your_token_here"
```

#### Get Events

```bash
curl -X GET "http://localhost:5000/api/events?category=concert&city=Delhi" \
  -H "Authorization: Bearer $TOKEN"
```

#### Send OTP

```bash
curl -X POST http://localhost:5000/api/otp/send \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "method": "email",
    "purpose": "booking"
  }'
```

#### Verify OTP

```bash
curl -X POST http://localhost:5000/api/otp/verify \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "code": "123456",
    "method": "email",
    "purpose": "booking"
  }'
```

#### Create Booking

```bash
curl -X POST http://localhost:5000/api/bookings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "eventId": "event_id",
    "seats": ["A1", "A2"],
    "customerName": "John Doe",
    "customerEmail": "john@example.com",
    "customerPhone": "9876543210",
    "otpVerified": true,
    "otpMethod": "email"
  }'
```

#### Chat Message

```bash
curl -X POST http://localhost:5000/api/chat/message \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What is the ticket price?",
    "eventContext": "event_id"
  }'
```

## Real-time Testing

### Socket.IO Testing

#### Test Connection

Open browser console:

```javascript
import { socketService } from '@/lib/socket-service'

// Connect
socketService.connect(token).then(() => {
  console.log('Connected')
})

// Join event
socketService.joinEvent('event_id')

// Listen for updates
socketService.onSeatsUpdated('event_id', (data) => {
  console.log('Seats updated:', data)
})
```

## Troubleshooting

### Common Issues

#### Issue: "Cannot connect to backend"

**Solution**:
1. Check backend is running: `http://localhost:5000/api/health`
2. Check CORS configuration in backend
3. Verify `NEXT_PUBLIC_API_URL` in frontend .env

#### Issue: "OTP not received"

**Solution**:
1. Check email service configuration
2. Check server logs: `node backend/server.js`
3. Check spam folder
4. For testing, check server console output

#### Issue: "Chatbot not responding"

**Solution**:
1. Verify Groq API key is valid
2. Check API rate limits
3. Check backend logs for Groq errors

#### Issue: "Real-time updates not working"

**Solution**:
1. Verify Socket.IO is connected
2. Check browser console for errors
3. Verify CORS in Socket.IO configuration
4. Check firewall settings

## Test Data

### Sample Events

```javascript
{
  title: "Summer Music Festival",
  category: "concert",
  eventDate: new Date(2024, 6, 15),
  eventTime: "18:00",
  venue: {
    name: "Grand Arena",
    address: "123 Music Street",
    city: "Delhi",
    state: "Delhi",
    postalCode: "110001",
    latitude: 28.7041,
    longitude: 77.1025
  },
  totalSeats: 200,
  ticketPrice: 500
}
```

### Sample Booking

```javascript
{
  eventId: "event_123",
  seats: ["A1", "A2", "A3"],
  customerName: "John Doe",
  customerEmail: "john@example.com",
  customerPhone: "9876543210",
  otpVerified: true,
  otpMethod: "email"
}
```

## Performance Testing

### Load Testing

Test with multiple concurrent users:

```bash
# Using Apache Bench
ab -n 100 -c 10 http://localhost:3000/

# Using wrk
wrk -t4 -c100 -d30s http://localhost:3000/
```

### Database Query Performance

Monitor MongoDB queries:

```bash
# In mongosh
db.setProfilingLevel(1, { slowms: 100 })
db.system.profile.find().limit(5).sort({ ts: -1 }).pretty()
```

## Automated Testing (Optional)

Setup Jest and React Testing Library:

```bash
pnpm add --save-dev jest @testing-library/react
```

Example test:

```typescript
import { render, screen } from '@testing-library/react'
import { EventCard } from '@/components/shared/event-card'

test('displays event title', () => {
  const event = { title: 'Test Event', ... }
  render(<EventCard event={event} />)
  expect(screen.getByText('Test Event')).toBeInTheDocument()
})
```

## Conclusion

This testing guide ensures all features are working correctly. Run through these tests before deploying to production. Document any issues found and create fixes accordingly.

For additional help, refer to the API documentation and backend README.
