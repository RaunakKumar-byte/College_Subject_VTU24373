import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, differenceInDays, formatDistance } from 'date-fns'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Date Formatting
export const formatDate = (date: Date | string): string => {
  return format(new Date(date), 'MMM dd, yyyy')
}

export const formatDateTime = (date: Date | string): string => {
  return format(new Date(date), 'MMM dd, yyyy hh:mm a')
}

export const formatTime = (date: Date | string): string => {
  return format(new Date(date), 'hh:mm a')
}

export const getTimeUntilEvent = (eventDate: Date | string): string => {
  return formatDistance(new Date(eventDate), new Date(), { addSuffix: true })
}

export const getDaysUntilEvent = (eventDate: Date | string): number => {
  return differenceInDays(new Date(eventDate), new Date())
}

// Price Formatting
export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(price)
}

// Ticket Number Generation
export const generateTicketNumber = (): string => {
  return `TKT-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`
}

// Confirmation Code Generation
export const generateConfirmationCode = (): string => {
  return Math.random().toString(36).substring(2, 10).toUpperCase()
}

// Seat Layout Generation
export const generateSeats = (rows: string[], seatsPerRow: number) => {
  const seats = []
  for (const row of rows) {
    for (let col = 1; col <= seatsPerRow; col++) {
      seats.push({
        seatNumber: `${row}${col}`,
        row,
        column: col,
      })
    }
  }
  return seats
}

// Email Validation
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Phone Validation
export const isValidPhone = (phone: string): boolean => {
  const phoneRegex = /^[0-9]{10}$/
  return phoneRegex.test(phone.replace(/\D/g, ''))
}

// Seat Selection Helper
export const calculateBookingTotal = (seatCount: number, ticketPrice: number): number => {
  return seatCount * ticketPrice
}

// Calculate Occupancy Rate
export const calculateOccupancyRate = (bookedSeats: number, totalSeats: number): number => {
  return Math.round((bookedSeats / totalSeats) * 100)
}
