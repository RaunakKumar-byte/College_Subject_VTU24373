export const EVENT_CATEGORIES = [
  { value: 'Concert', label: 'Concert', icon: '🎵' },
  { value: 'Workshop', label: 'Workshop', icon: '🛠️' },
  { value: 'Seminar', label: 'Seminar', icon: '📚' },
  { value: 'Webinar', label: 'Webinar', icon: '💻' },
  { value: 'Social', label: 'Social Event', icon: '🎉' },
] as const;

export const PAYMENT_METHODS = [
  { value: 'CreditCard', label: 'Credit Card' },
  { value: 'DebitCard', label: 'Debit Card' },
  { value: 'UPI', label: 'UPI' },
  { value: 'NetBanking', label: 'Net Banking' },
] as const;

export const BOOKING_STATUS = {
  PENDING: 'Pending',
  CONFIRMED: 'Confirmed',
  CANCELLED: 'Cancelled',
} as const;

export const NOTIFICATION_TYPES = {
  CONFIRMATION: 'Confirmation',
  CANCELLATION: 'Cancellation',
  REMINDER: 'Reminder',
} as const;

export const SEAT_LAYOUT = {
  ROWS: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'],
  SEATS_PER_ROW: 10,
};

export const DEFAULT_PAGINATION = {
  PAGE_SIZE: 10,
  INITIAL_PAGE: 1,
} as const;

export const TOAST_CONFIG = {
  DURATION: 3000,
  POSITION: 'bottom-right',
} as const;
