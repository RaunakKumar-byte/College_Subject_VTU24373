import axios, { AxiosInstance, AxiosError } from 'axios'

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api'

class APIClient {
  private client: AxiosInstance

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    // Add token to requests
    this.client.interceptors.request.use(config => {
      const token = this.getToken()
      if (token) {
        config.headers.Authorization = `Bearer ${token}`
      }
      return config
    })

    // Handle errors
    this.client.interceptors.response.use(
      response => response,
      error => {
        if (error.response?.status === 401) {
          this.clearToken()
          window.location.href = '/login'
        }
        return Promise.reject(error)
      }
    )
  }

  // Token management
  private getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('token')
    }
    return null
  }

  private clearToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
    }
  }

  public setToken(token: string, user: any): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
    }
  }

  // Auth endpoints
  async register(data: {
    firstName: string
    lastName: string
    email: string
    phone: string
    password: string
    passwordConfirm: string
  }) {
    const response = await this.client.post('/auth/register', data)
    if (response.data.success) {
      this.setToken(response.data.token, response.data.user)
    }
    return response.data
  }

  async login(email: string, password: string) {
    const response = await this.client.post('/auth/login', { email, password })
    if (response.data.success) {
      this.setToken(response.data.token, response.data.user)
    }
    return response.data
  }

  async getCurrentUser() {
    const response = await this.client.get('/auth/me')
    return response.data
  }

  async updateProfile(data: any) {
    const response = await this.client.put('/auth/profile', data)
    return response.data
  }

  // OTP endpoints
  async sendOTP(method: 'email' | 'phone', purpose?: string) {
    const response = await this.client.post('/otp/send', { method, purpose })
    return response.data
  }

  async verifyOTP(code: string, method: 'email' | 'phone', purpose?: string) {
    const response = await this.client.post('/otp/verify', { code, method, purpose })
    return response.data
  }

  async resendOTP(method: 'email' | 'phone', purpose?: string) {
    const response = await this.client.post('/otp/resend', { method, purpose })
    return response.data
  }

  // Event endpoints
  async getEvents(filters?: { category?: string; city?: string; search?: string; date?: string }) {
    const response = await this.client.get('/events', { params: filters })
    return response.data
  }

  async getEventById(id: string) {
    const response = await this.client.get(`/events/${id}`)
    return response.data
  }

  async getEventSeats(eventId: string) {
    const response = await this.client.get(`/events/${eventId}/seats`)
    return response.data
  }

  async createEvent(data: any) {
    const response = await this.client.post('/events', data)
    return response.data
  }

  async updateEvent(id: string, data: any) {
    const response = await this.client.put(`/events/${id}`, data)
    return response.data
  }

  async deleteEvent(id: string) {
    const response = await this.client.delete(`/events/${id}`)
    return response.data
  }

  // Booking endpoints
  async createBooking(data: any) {
    const response = await this.client.post('/bookings', data)
    return response.data
  }

  async getBookings() {
    const response = await this.client.get('/bookings')
    return response.data
  }

  async getBookingById(id: string) {
    const response = await this.client.get(`/bookings/${id}`)
    return response.data
  }

  async cancelBooking(id: string) {
    const response = await this.client.put(`/bookings/${id}/cancel`)
    return response.data
  }

  // Email endpoints
  async sendConfirmationEmail(bookingId: string) {
    const response = await this.client.post('/email/send-confirmation', { bookingId })
    return response.data
  }

  async sendReminderEmail(eventId: string) {
    const response = await this.client.post('/email/send-reminder', { eventId })
    return response.data
  }

  async sendCancellationEmail(bookingId: string) {
    const response = await this.client.post('/email/send-cancellation', { bookingId })
    return response.data
  }

  // Chat endpoints
  async sendChatMessage(message: string, eventContext?: string) {
    const response = await this.client.post('/chat/message', { message, eventContext })
    return response.data
  }

  async getFAQs() {
    const response = await this.client.get('/chat/faq')
    return response.data
  }

  // User endpoints
  async getUserProfile() {
    const response = await this.client.get('/user/profile')
    return response.data
  }

  async getUserBookings() {
    const response = await this.client.get('/user/bookings')
    return response.data
  }

  async getUserStats() {
    const response = await this.client.get('/user/stats')
    return response.data
  }

  async updateOTPPreference(method: 'email' | 'phone') {
    const response = await this.client.put('/user/otp-preference', { method })
    return response.data
  }
}

export const apiClient = new APIClient()
