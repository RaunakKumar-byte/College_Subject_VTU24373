// Event Types
export type EventCategory = 'Concert' | 'Workshop' | 'Seminar' | 'Webinar' | 'Social';
export type PaymentMethod = 'CreditCard' | 'DebitCard' | 'UPI' | 'NetBanking';
export type BookingStatus = 'Pending' | 'Confirmed' | 'Cancelled';

export interface Event {
  id: string;
  title: string;
  category: EventCategory;
  description: string;
  startDate: Date;
  endDate: Date;
  duration: number; // in minutes
  location: string;
  capacity: number;
  totalSeats: number;
  availableSeats: number;
  ticketPrice: number;
  image: string;
  organizerId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Seat {
  id: string;
  eventId: string;
  seatNumber: string;
  row: string;
  column: number;
  isBooked: boolean;
  bookingId: string | null;
  createdAt: Date;
}

export interface Booking {
  id: string;
  eventId: string;
  userId: string;
  attendeeName: string;
  attendeeEmail: string;
  attendeePhone: string;
  seatNumbers: string[];
  quantity: number;
  totalPrice: number;
  paymentMethod: PaymentMethod;
  status: BookingStatus;
  bookingDate: Date;
  ticketNumber: string;
  confirmationCode: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  password: string;
  role: 'admin' | 'user';
  createdAt: Date;
  updatedAt: Date;
}

export interface Notification {
  id: string;
  bookingId: string;
  recipientEmail: string;
  type: 'Confirmation' | 'Cancellation' | 'Reminder';
  status: 'Sent' | 'Failed' | 'Pending';
  sentAt: Date | null;
}

export interface Analytics {
  totalRevenue: number;
  totalBookings: number;
  totalSeatsBooked: number;
  eventBookingStats: {
    eventId: string;
    eventTitle: string;
    bookings: number;
    revenue: number;
    occupancyRate: number;
  }[];
  recentBookings: Booking[];
}
