import { io, Socket } from 'socket.io-client'

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000'

class SocketService {
  private socket: Socket | null = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5

  connect(token?: string): Promise<Socket> {
    return new Promise((resolve, reject) => {
      if (this.socket?.connected) {
        resolve(this.socket)
        return
      }

      const options: any = {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: this.maxReconnectAttempts,
      }

      if (token) {
        options.auth = { token }
      }

      this.socket = io(SOCKET_URL, options)

      this.socket.on('connect', () => {
        console.log('[Socket] Connected')
        this.reconnectAttempts = 0
        resolve(this.socket!)
      })

      this.socket.on('connect_error', error => {
        console.error('[Socket] Connection error:', error)
        this.reconnectAttempts++
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
          reject(error)
        }
      })

      this.socket.on('disconnect', reason => {
        console.log('[Socket] Disconnected:', reason)
      })

      // Set timeout for connection
      setTimeout(() => {
        if (!this.socket?.connected) {
          reject(new Error('Socket connection timeout'))
        }
      }, 10000)
    })
  }

  disconnect(): void {
    if (this.socket?.connected) {
      this.socket.disconnect()
      this.socket = null
    }
  }

  // Real-time event listeners
  onSeatsUpdated(eventId: string, callback: (data: any) => void): void {
    if (this.socket) {
      this.socket.on('seats-updated', callback)
    }
  }

  onBookingConfirmed(callback: (data: any) => void): void {
    if (this.socket) {
      this.socket.on('booking-confirmed', callback)
    }
  }

  onBookingCreated(callback: (data: any) => void): void {
    if (this.socket) {
      this.socket.on('booking-created', callback)
    }
  }

  // Emit events
  joinEvent(eventId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('join-event', eventId)
    }
  }

  leaveEvent(eventId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('leave-event', eventId)
    }
  }

  joinUserRoom(userId: string): void {
    if (this.socket?.connected) {
      this.socket.emit('join-user', userId)
    }
  }

  // Cleanup listeners
  removeAllListeners(): void {
    if (this.socket) {
      this.socket.removeAllListeners()
    }
  }

  removeListener(event: string): void {
    if (this.socket) {
      this.socket.removeListener(event)
    }
  }

  isConnected(): boolean {
    return this.socket?.connected ?? false
  }

  getSocket(): Socket | null {
    return this.socket
  }
}

export const socketService = new SocketService()
