import { z } from 'zod';

// Event Validation
export const eventCreateSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters').max(200),
  category: z.enum(['Concert', 'Workshop', 'Seminar', 'Webinar', 'Social']),
  description: z.string().min(10, 'Description must be at least 10 characters').max(2000),
  startDate: z.coerce.date(),
  endDate: z.coerce.date(),
  duration: z.number().min(15, 'Duration must be at least 15 minutes').max(1440),
  location: z.string().min(5, 'Location is required'),
  capacity: z.number().min(10, 'Capacity must be at least 10').max(1000),
  ticketPrice: z.number().min(0, 'Price must be non-negative').max(100000),
  image: z.string().url('Valid image URL required'),
}).refine((data) => data.endDate > data.startDate, {
  message: 'End date must be after start date',
  path: ['endDate'],
});

// Booking Validation
export const bookingSchema = z.object({
  eventId: z.string().min(1, 'Event ID is required'),
  attendeeName: z.string().min(2, 'Name must be at least 2 characters').max(100),
  attendeeEmail: z.string().email('Valid email is required'),
  attendeePhone: z.string().regex(/^[0-9]{10}$/, 'Phone number must be 10 digits'),
  seatNumbers: z.array(z.string()).min(1, 'At least one seat must be selected'),
  paymentMethod: z.enum(['CreditCard', 'DebitCard', 'UPI', 'NetBanking']),
  termsAccepted: z.boolean().refine((val) => val === true, {
    message: 'You must accept the terms and conditions',
  }),
});

// User Authentication
export const loginSchema = z.object({
  email: z.string().email('Valid email is required'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export const signupSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.string().email('Valid email is required'),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  confirmPassword: z.string(),
  phone: z.string().regex(/^[0-9]{10}$/, 'Phone number must be 10 digits'),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

// Type exports for use in components
export type EventCreateInput = z.infer<typeof eventCreateSchema>;
export type BookingInput = z.infer<typeof bookingSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type SignupInput = z.infer<typeof signupSchema>;
