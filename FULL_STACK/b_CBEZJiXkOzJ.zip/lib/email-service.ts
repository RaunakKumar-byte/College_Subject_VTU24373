import { Booking, Event, Notification } from '@/lib/types'
import { formatDate, formatTime, formatPrice } from '@/lib/utils'

// Email templates
const emailTemplates = {
  bookingConfirmation: (booking: Booking, event: Event) => ({
    subject: `Booking Confirmed - ${event.title}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center;">
          <h1>Booking Confirmed!</h1>
        </div>
        
        <div style="padding: 20px; background: #f5f5f5;">
          <h2 style="color: #333;">Hello ${booking.attendeeName},</h2>
          <p>Thank you for booking tickets for our event. Your booking has been confirmed.</p>
          
          <div style="background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #667eea;">
            <h3 style="color: #333; margin-top: 0;">Event Details</h3>
            <p><strong>Event:</strong> ${event.title}</p>
            <p><strong>Category:</strong> ${event.category}</p>
            <p><strong>Date:</strong> ${formatDate(event.startDate)}</p>
            <p><strong>Time:</strong> ${formatTime(event.startDate)}</p>
            <p><strong>Location:</strong> ${event.location}</p>
          </div>
          
          <div style="background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #667eea;">
            <h3 style="color: #333; margin-top: 0;">Booking Information</h3>
            <p><strong>Confirmation Code:</strong> <code style="background: #f0f0f0; padding: 5px; border-radius: 3px;">${booking.confirmationCode}</code></p>
            <p><strong>Ticket Number:</strong> <code style="background: #f0f0f0; padding: 5px; border-radius: 3px;">${booking.ticketNumber}</code></p>
            <p><strong>Seats:</strong> ${booking.seatNumbers.join(', ')}</p>
            <p><strong>Quantity:</strong> ${booking.quantity}</p>
            <p><strong>Total Amount Paid:</strong> ${formatPrice(booking.totalPrice)}</p>
          </div>
          
          <div style="background: #fff3cd; padding: 15px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #ffc107;">
            <p style="margin: 0;"><strong>Important:</strong> Please bring a valid ID and your confirmation code to the venue. Arrive at least 15 minutes before the event starts.</p>
          </div>
          
          <p style="color: #666; font-size: 14px; margin-top: 20px;">
            If you have any questions, please contact our support team.
          </p>
        </div>
        
        <div style="text-align: center; padding: 20px; background: #333; color: white; font-size: 12px;">
          <p>© 2024 EventHub. All rights reserved.</p>
        </div>
      </div>
    `,
  }),

  bookingCancellation: (booking: Booking, event: Event) => ({
    subject: `Booking Cancelled - ${event.title}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 20px; text-align: center;">
          <h1>Booking Cancelled</h1>
        </div>
        
        <div style="padding: 20px; background: #f5f5f5;">
          <h2 style="color: #333;">Hello ${booking.attendeeName},</h2>
          <p>Your booking for the following event has been cancelled:</p>
          
          <div style="background: white; padding: 20px; margin: 20px 0; border-radius: 8px;">
            <h3 style="color: #333; margin-top: 0;">${event.title}</h3>
            <p><strong>Date:</strong> ${formatDate(event.startDate)}</p>
            <p><strong>Location:</strong> ${event.location}</p>
            <p><strong>Refund Amount:</strong> ${formatPrice(booking.totalPrice)}</p>
          </div>
          
          <p style="color: #666;">The refund will be processed within 5-7 business days.</p>
        </div>
        
        <div style="text-align: center; padding: 20px; background: #333; color: white; font-size: 12px;">
          <p>© 2024 EventHub. All rights reserved.</p>
        </div>
      </div>
    `,
  }),

  eventReminder: (booking: Booking, event: Event) => ({
    subject: `Reminder: ${event.title} is coming soon!`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center;">
          <h1>Event Reminder</h1>
        </div>
        
        <div style="padding: 20px; background: #f5f5f5;">
          <h2 style="color: #333;">Hello ${booking.attendeeName},</h2>
          <p>This is a friendly reminder that your event is coming up soon!</p>
          
          <div style="background: white; padding: 20px; margin: 20px 0; border-radius: 8px;">
            <h3 style="color: #333; margin-top: 0;">${event.title}</h3>
            <p><strong>Date & Time:</strong> ${formatDate(event.startDate)} at ${formatTime(event.startDate)}</p>
            <p><strong>Location:</strong> ${event.location}</p>
            <p><strong>Seats:</strong> ${booking.seatNumbers.join(', ')}</p>
          </div>
          
          <p style="color: #666;">Don't forget to bring your confirmation code and valid ID!</p>
        </div>
        
        <div style="text-align: center; padding: 20px; background: #333; color: white; font-size: 12px;">
          <p>© 2024 EventHub. All rights reserved.</p>
        </div>
      </div>
    `,
  }),
}

// Email service - ready for Resend or similar integration
export class EmailService {
  /**
   * Send booking confirmation email
   * When connected to Resend or similar service, replace the mock implementation
   */
  static async sendBookingConfirmation(booking: Booking, event: Event): Promise<void> {
    const emailTemplate = emailTemplates.bookingConfirmation(booking, event)
    await this.sendEmail(booking.attendeeEmail, emailTemplate.subject, emailTemplate.html)
  }

  /**
   * Send booking cancellation email
   */
  static async sendCancellationEmail(booking: Booking, event: Event): Promise<void> {
    const emailTemplate = emailTemplates.bookingCancellation(booking, event)
    await this.sendEmail(booking.attendeeEmail, emailTemplate.subject, emailTemplate.html)
  }

  /**
   * Send event reminder email
   */
  static async sendEventReminder(booking: Booking, event: Event): Promise<void> {
    const emailTemplate = emailTemplates.eventReminder(booking, event)
    await this.sendEmail(booking.attendeeEmail, emailTemplate.subject, emailTemplate.html)
  }

  /**
   * Core email sending method
   * Replace with actual email service integration (Resend, SendGrid, etc.)
   */
  private static async sendEmail(to: string, subject: string, html: string): Promise<void> {
    // Mock implementation - replace with actual email service
    console.log(`[Mock Email Service] Sending email to ${to}`)
    console.log(`Subject: ${subject}`)
    console.log(`Body: ${html.substring(0, 100)}...`)

    // In production, integrate with Resend:
    // import { Resend } from 'resend'
    // const resend = new Resend(process.env.RESEND_API_KEY)
    // await resend.emails.send({
    //   from: 'noreply@eventhub.com',
    //   to,
    //   subject,
    //   html,
    // })

    // Or SendGrid:
    // import sgMail from '@sendgrid/mail'
    // sgMail.setApiKey(process.env.SENDGRID_API_KEY!)
    // await sgMail.send({
    //   to,
    //   from: 'noreply@eventhub.com',
    //   subject,
    //   html,
    // })
  }
}

/**
 * Notification service to manage all event notifications
 */
export class NotificationService {
  /**
   * Handle booking confirmation
   */
  static async handleBookingConfirmed(booking: Booking, event: Event): Promise<Notification> {
    // Send email
    await EmailService.sendBookingConfirmation(booking, event)

    // Log notification (in real app, save to database)
    const notification: Notification = {
      id: `notif-${Date.now()}`,
      bookingId: booking.id,
      recipientEmail: booking.attendeeEmail,
      type: 'Confirmation',
      status: 'Sent',
      sentAt: new Date(),
    }

    console.log('[Notification Service] Booking confirmation sent', notification)
    return notification
  }

  /**
   * Handle booking cancellation
   */
  static async handleBookingCancelled(booking: Booking, event: Event): Promise<Notification> {
    await EmailService.sendCancellationEmail(booking, event)

    const notification: Notification = {
      id: `notif-${Date.now()}`,
      bookingId: booking.id,
      recipientEmail: booking.attendeeEmail,
      type: 'Cancellation',
      status: 'Sent',
      sentAt: new Date(),
    }

    console.log('[Notification Service] Cancellation email sent', notification)
    return notification
  }

  /**
   * Send event reminder (call 1 day before event)
   */
  static async sendEventReminder(booking: Booking, event: Event): Promise<Notification> {
    await EmailService.sendEventReminder(booking, event)

    const notification: Notification = {
      id: `notif-${Date.now()}`,
      bookingId: booking.id,
      recipientEmail: booking.attendeeEmail,
      type: 'Reminder',
      status: 'Sent',
      sentAt: new Date(),
    }

    console.log('[Notification Service] Event reminder sent', notification)
    return notification
  }
}
